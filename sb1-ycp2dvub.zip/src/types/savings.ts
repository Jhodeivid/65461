export interface SavingsBox {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  target_amount: number;
  current_amount: number;
  monthly_contribution: number;
  target_date?: string;
  bank_name: string;
  cdi_percentage: number; // Percentual do CDI (100 = 100% do CDI)
  created_at: string;
  updated_at: string;
  is_active: boolean;
  auto_invest: boolean;
  risk_level: 'low' | 'medium' | 'high';
}

export interface CDIRate {
  id: string;
  date: string;
  rate: number; // Taxa anual em percentual
  source: string;
  created_at: string;
}

export interface WhatsAppUser {
  id: string;
  user_id: string;
  phone_number: string;
  whatsapp_number: string;
  is_verified: boolean;
  verification_code?: string;
  verification_expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface WhatsAppMessage {
  id: string;
  user_id: string;
  whatsapp_number: string;
  message_text: string;
  message_type: 'incoming' | 'outgoing';
  ai_response?: string;
  action_taken?: string;
  success: boolean;
  error_message?: string;
  created_at: string;
}

export interface SavingsProjection {
  months: number;
  finalAmount: number;
  totalInterest: number;
  monthlyBreakdown: Array<{
    month: number;
    contribution: number;
    interest: number;
    balance: number;
  }>;
}