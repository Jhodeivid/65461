import { useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import { realtimeManager } from '../lib/realtime';

interface UseRealtimeUpdatesProps {
  onTransactionUpdate?: (payload: any) => void;
  onSavingsUpdate?: (payload: any) => void;
  onWhatsAppMessage?: (payload: any) => void;
}

export const useRealtimeUpdates = ({
  onTransactionUpdate,
  onSavingsUpdate,
  onWhatsAppMessage
}: UseRealtimeUpdatesProps = {}) => {
  const { user } = useAuth();

  // Callback para transações
  const handleTransactionUpdate = useCallback((payload: any) => {
    console.log('Realtime: Nova transação recebida', payload);
    
    // Mostrar notificação
    if ('Notification' in window && Notification.permission === 'granted') {
      const transaction = payload.new;
      const type = transaction.type === 'income' ? 'Receita' : 'Despesa';
      const amount = new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(transaction.amount);
      
      new Notification(`${type} Registrada`, {
        body: `${amount} - ${transaction.title}`,
        icon: '/favicon.ico'
      });
    }

    if (onTransactionUpdate) {
      onTransactionUpdate(payload);
    }
  }, [onTransactionUpdate]);

  // Callback para caixinhas
  const handleSavingsUpdate = useCallback((payload: any) => {
    console.log('Realtime: Caixinha atualizada', payload);
    
    if ('Notification' in window && Notification.permission === 'granted') {
      const savings = payload.new;
      if (payload.eventType === 'INSERT') {
        new Notification('Nova Caixinha Criada', {
          body: `${savings.name} - Meta: R$ ${savings.target_amount.toFixed(2)}`,
          icon: '/favicon.ico'
        });
      } else if (payload.eventType === 'UPDATE') {
        new Notification('Caixinha Atualizada', {
          body: `${savings.name} - Saldo: R$ ${savings.current_amount.toFixed(2)}`,
          icon: '/favicon.ico'
        });
      }
    }

    if (onSavingsUpdate) {
      onSavingsUpdate(payload);
    }
  }, [onSavingsUpdate]);

  // Callback para mensagens WhatsApp
  const handleWhatsAppMessage = useCallback((payload: any) => {
    console.log('Realtime: Nova mensagem WhatsApp', payload);
    
    if ('Notification' in window && Notification.permission === 'granted') {
      const message = payload.new;
      new Notification('WhatsApp - Sofia', {
        body: message.ai_response || 'Nova mensagem processada',
        icon: '/favicon.ico'
      });
    }

    if (onWhatsAppMessage) {
      onWhatsAppMessage(payload);
    }
  }, [onWhatsAppMessage]);

  // Configurar subscrições
  useEffect(() => {
    if (!user) return;

    console.log('Configurando subscrições realtime para usuário:', user.id);

    // Solicitar permissão para notificações
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    const unsubscribeTransactions = realtimeManager.subscribeToTransactions(
      user.id, 
      handleTransactionUpdate
    );

    const unsubscribeSavings = realtimeManager.subscribeToSavingsBoxes(
      user.id, 
      handleSavingsUpdate
    );

    const unsubscribeWhatsApp = realtimeManager.subscribeToWhatsAppMessages(
      user.id, 
      handleWhatsAppMessage
    );

    // Cleanup ao desmontar
    return () => {
      console.log('Limpando subscrições realtime');
      unsubscribeTransactions();
      unsubscribeSavings();
      unsubscribeWhatsApp();
    };
  }, [user, handleTransactionUpdate, handleSavingsUpdate, handleWhatsAppMessage]);

  return {
    isConnected: !!user
  };
};