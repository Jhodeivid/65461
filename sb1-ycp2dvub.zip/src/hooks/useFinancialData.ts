import { useState, useCallback, useEffect } from 'react';
import { Account, Card, Transaction, Goal, Limit } from '../types/financial';
import { Category, SubCategory, defaultCategories } from '../data/categories';

// Dados iniciais vazios para contas novas
const initialAccounts: Account[] = [];
const initialCards: Card[] = [];
const initialTransactions: Transaction[] = [];
const initialGoals: Goal[] = [];
const initialLimits: Limit[] = [];

export const useFinancialData = () => {
  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem('financial_accounts');
    return saved ? JSON.parse(saved) : initialAccounts;
  });
  
  const [cards, setCards] = useState<Card[]>(() => {
    const saved = localStorage.getItem('financial_cards');
    return saved ? JSON.parse(saved) : initialCards;
  });
  
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('financial_transactions');
    return saved ? JSON.parse(saved) : initialTransactions;
  });
  
  const [customCategories, setCustomCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('financial_categories');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem('financial_goals');
    return saved ? JSON.parse(saved) : initialGoals;
  });
  
  const [limits, setLimits] = useState<Limit[]>(() => {
    const saved = localStorage.getItem('financial_limits');
    return saved ? JSON.parse(saved) : initialLimits;
  });

  // Salvar no localStorage sempre que os dados mudarem
  useEffect(() => {
    localStorage.setItem('financial_accounts', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem('financial_cards', JSON.stringify(cards));
  }, [cards]);

  useEffect(() => {
    localStorage.setItem('financial_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('financial_categories', JSON.stringify(customCategories));
  }, [customCategories]);

  useEffect(() => {
    localStorage.setItem('financial_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('financial_limits', JSON.stringify(limits));
  }, [limits]);

  const addAccount = useCallback((account: Omit<Account, 'id'>) => {
    const newAccount: Account = {
      ...account,
      id: `account_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      balance: Number(account.balance) || 0
    };
    
    console.log('Adicionando conta:', newAccount);
    setAccounts(prev => {
      const updated = [...prev, newAccount];
      console.log('Contas atualizadas:', updated);
      return updated;
    });
  }, []);

  const updateAccount = useCallback((accountId: string, updates: Partial<Account>) => {
    setAccounts(prev => prev.map(account => 
      account.id === accountId ? { ...account, ...updates } : account
    ));
  }, []);

  const deleteAccount = useCallback((accountId: string) => {
    setAccounts(prev => prev.filter(account => account.id !== accountId));
  }, []);

  const addCard = useCallback((card: Omit<Card, 'id'>) => {
    const newCard: Card = {
      ...card,
      id: `card_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      limit: Number(card.limit) || 0,
      used: Number(card.used) || 0
    };
    
    console.log('Adicionando cartão:', newCard);
    setCards(prev => {
      const updated = [...prev, newCard];
      console.log('Cartões atualizados:', updated);
      return updated;
    });
  }, []);

  const updateCard = useCallback((cardId: string, updates: Partial<Card>) => {
    setCards(prev => prev.map(card => 
      card.id === cardId ? { ...card, ...updates } : card
    ));
  }, []);

  const addGoal = useCallback((goal: Omit<Goal, 'id' | 'createdAt'>) => {
    // Calcular estimativa de tempo e verificar se é realista
    const monthsToTarget = goal.monthlyContribution > 0 ? 
      Math.ceil((goal.targetAmount - goal.currentAmount) / goal.monthlyContribution) : 0;
    
    const targetDate = new Date(goal.targetDate);
    const today = new Date();
    const monthsAvailable = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 30));
    
    const isRealistic = monthsToTarget <= monthsAvailable;
    let aiSuggestion = '';
    
    if (!isRealistic && goal.monthlyContribution > 0) {
      const requiredMonthly = Math.ceil((goal.targetAmount - goal.currentAmount) / monthsAvailable);
      aiSuggestion = `Para alcançar sua meta até ${targetDate.toLocaleDateString('pt-PT')}, você precisaria poupar ${requiredMonthly.toFixed(2)}€ por mês em vez de ${goal.monthlyContribution.toFixed(2)}€.`;
    }
    
    const newGoal: Goal = {
      ...goal,
      id: `goal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      estimatedMonths: monthsToTarget,
      isRealistic,
      aiSuggestion,
    };
    
    console.log('Adicionando meta:', newGoal);
    setGoals(prev => [...prev, newGoal]);
  }, []);

  const updateGoal = useCallback((goalId: string, updates: Partial<Goal>) => {
    setGoals(prev => prev.map(goal => 
      goal.id === goalId ? { ...goal, ...updates } : goal
    ));
  }, []);

  const addLimit = useCallback((limit: Omit<Limit, 'id' | 'createdAt' | 'resetDate'>) => {
    const startDate = new Date(limit.startDate);
    const now = new Date();
    let resetDate = new Date(startDate);
    
    switch (limit.period) {
      case 'biweekly':
        resetDate.setDate(resetDate.getDate() + 14);
        break;
      case 'monthly':
        resetDate.setMonth(resetDate.getMonth() + 1);
        break;
      case 'bimonthly':
        resetDate.setMonth(resetDate.getMonth() + 2);
        break;
      case 'quarterly':
        resetDate.setMonth(resetDate.getMonth() + 3);
        break;
      case 'semiannual':
        resetDate.setMonth(resetDate.getMonth() + 6);
        break;
      case 'annual':
        resetDate.setFullYear(resetDate.getFullYear() + 1);
        break;
    }

    const newLimit: Limit = {
      ...limit,
      id: `limit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: now.toISOString(),
      startDate: limit.startDate,
      resetDate: resetDate.toISOString(),
    };
    
    console.log('Adicionando limite:', newLimit);
    setLimits(prev => [...prev, newLimit]);
  }, []);

  const updateLimit = useCallback((limitId: string, updates: Partial<Limit>) => {
    setLimits(prev => prev.map(limit => 
      limit.id === limitId ? { ...limit, ...updates } : limit
    ));
  }, []);

  const addTransaction = useCallback((transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: `transaction_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      date: transaction.date || new Date().toISOString().split('T')[0],
      amount: Number(transaction.amount) || 0,
      userDescription: (transaction as any).userDescription || transaction.description
    };

    console.log('Adicionando transação:', newTransaction);
    
    // Validação de saldo insuficiente para transferências
    if (newTransaction.type === 'transfer' && newTransaction.transferInfo) {
      const fromAccount = accounts.find(acc => acc.id === newTransaction.transferInfo?.fromAccountId);
      if (fromAccount && newTransaction.amount > fromAccount.balance) {
        console.error('Saldo insuficiente para transferência');
        throw new Error(`Saldo insuficiente na ${fromAccount.name}. Saldo disponível: ${fromAccount.balance.toFixed(2)}€`);
      }
    }

    // Validação de conta existente para receitas com payment_source específico
    if (newTransaction.type === 'income' && newTransaction.paymentMethod === 'account' && newTransaction.paymentSource) {
      const targetAccount = accounts.find(acc => acc.id === newTransaction.paymentSource);
      if (!targetAccount) {
        console.error('Conta de destino não encontrada para receita');
        throw new Error(`A conta especificada não foi encontrada. Crie a conta primeiro.`);
      }
    }

    // Validação de saldo para despesas em conta
    if (newTransaction.type === 'expense' && newTransaction.paymentMethod === 'account' && newTransaction.paymentSource) {
      const sourceAccount = accounts.find(acc => acc.id === newTransaction.paymentSource);
      if (sourceAccount && newTransaction.amount > sourceAccount.balance) {
        console.error('Saldo insuficiente para despesa');
        throw new Error(`Saldo insuficiente na ${sourceAccount.name}. Saldo disponível: ${sourceAccount.balance.toFixed(2)}€`);
      }
    }
    
    setTransactions(prev => {
      const updated = [...prev, newTransaction];
      console.log('Transações atualizadas:', updated);
      return updated;
    });

    // Atualizar limites quando adicionar despesa
    if (transaction.type === 'expense') {
      setLimits(prev => prev.map(limit => {
        if (limit.category === transaction.category && limit.isActive) {
          return { ...limit, currentAmount: limit.currentAmount + transaction.amount };
        }
        return limit;
      }));
    }

    // Atualizar saldos das contas - OPERAÇÃO ATÓMICA
    if (transaction.type === 'expense' && transaction.status === 'paid' && transaction.paymentMethod === 'account' && transaction.paymentSource) {
      setAccounts(prev => prev.map(account => {
        if (account.id === transaction.paymentSource) {
          const newBalance = Math.round((account.balance - transaction.amount) * 100) / 100;
          console.log(`Atualizando saldo da conta ${account.name}: ${account.balance} -> ${newBalance}`);
          return { ...account, balance: newBalance };
        }
        return account;
      }));
    } else if (transaction.type === 'income' && transaction.status === 'received' && transaction.paymentMethod === 'account' && transaction.paymentSource) {
      setAccounts(prev => prev.map(account => {
        if (account.id === transaction.paymentSource) {
          const newBalance = Math.round((account.balance + transaction.amount) * 100) / 100;
          console.log(`Atualizando saldo da conta ${account.name}: ${account.balance} -> ${newBalance}`);
          return { ...account, balance: newBalance };
        }
        return account;
      }));
    } else if (transaction.type === 'transfer' && transaction.transferInfo) {
      // Transferência: debitar da conta origem e creditar na conta destino
      setAccounts(prev => prev.map(account => {
        if (account.id === transaction.transferInfo?.fromAccountId) {
          const newBalance = Math.round((account.balance - transaction.amount) * 100) / 100;
          console.log(`Transferência - Debitar conta ${account.name}: ${account.balance} -> ${newBalance}`);
          return { ...account, balance: newBalance };
        } else if (account.id === transaction.transferInfo?.toAccountId) {
          const newBalance = Math.round((account.balance + transaction.amount) * 100) / 100;
          console.log(`Transferência - Creditar conta ${account.name}: ${account.balance} -> ${newBalance}`);
          return { ...account, balance: newBalance };
        }
        return account;
      }));
    }

    // Atualizar uso do cartão
    if (transaction.type === 'expense' && transaction.status === 'paid' && transaction.paymentMethod === 'card' && transaction.paymentSource) {
      setCards(prev => prev.map(card => {
        if (card.id === transaction.paymentSource) {
          const newUsed = card.used + transaction.amount;
          console.log(`Atualizando uso do cartão ${card.name}: ${card.used} -> ${newUsed}`);
          return { ...card, used: newUsed };
        }
        return card;
      }));
    }
  }, [accounts, cards]);

  const updateTransaction = useCallback((transactionId: string, updates: Partial<Transaction>) => {
    setTransactions(prev => prev.map(transaction => {
      if (transaction.id === transactionId) {
        const oldTransaction = transaction;
        const updatedTransaction = { ...transaction, ...updates };
        
        // Reverter efeitos da transação antiga
        if (oldTransaction.type === 'expense' && oldTransaction.status === 'paid' && oldTransaction.paymentMethod === 'account' && oldTransaction.paymentSource) {
          setAccounts(prevAccounts => prevAccounts.map(account => 
            account.id === oldTransaction.paymentSource 
              ? { ...account, balance: Math.round((account.balance + oldTransaction.amount) * 100) / 100 }
              : account
          ));
        } else if (oldTransaction.type === 'income' && oldTransaction.status === 'received' && oldTransaction.paymentMethod === 'account' && oldTransaction.paymentSource) {
          setAccounts(prevAccounts => prevAccounts.map(account => 
            account.id === oldTransaction.paymentSource 
              ? { ...account, balance: Math.round((account.balance - oldTransaction.amount) * 100) / 100 }
              : account
          ));
        } else if (oldTransaction.type === 'expense' && oldTransaction.status === 'paid' && oldTransaction.paymentMethod === 'card' && oldTransaction.paymentSource) {
          setCards(prevCards => prevCards.map(card => 
            card.id === oldTransaction.paymentSource 
              ? { ...card, used: card.used - oldTransaction.amount }
              : card
          ));
        }
        
        // Aplicar efeitos da transação atualizada
        if (updatedTransaction.type === 'expense' && updatedTransaction.status === 'paid' && updatedTransaction.paymentMethod === 'account' && updatedTransaction.paymentSource) {
          setAccounts(prevAccounts => prevAccounts.map(account => 
            account.id === updatedTransaction.paymentSource 
              ? { ...account, balance: Math.round((account.balance - updatedTransaction.amount) * 100) / 100 }
              : account
          ));
        } else if (updatedTransaction.type === 'income' && updatedTransaction.status === 'received' && updatedTransaction.paymentMethod === 'account' && updatedTransaction.paymentSource) {
          setAccounts(prevAccounts => prevAccounts.map(account => 
            account.id === updatedTransaction.paymentSource 
              ? { ...account, balance: Math.round((account.balance + updatedTransaction.amount) * 100) / 100 }
              : account
          ));
        } else if (updatedTransaction.type === 'expense' && updatedTransaction.status === 'paid' && updatedTransaction.paymentMethod === 'card' && updatedTransaction.paymentSource) {
          setCards(prevCards => prevCards.map(card => 
            card.id === updatedTransaction.paymentSource 
              ? { ...card, used: card.used + updatedTransaction.amount }
              : card
          ));
        }
        
        return updatedTransaction;
      }
      return transaction;
    }));
  }, []);

  const getFinancialSummary = useCallback(() => {
    console.log('Calculando resumo financeiro...');
    console.log('Contas:', accounts);
    console.log('Transações:', transactions);
    
    const totalBalance = accounts.reduce((sum, account) => {
      console.log(`Conta ${account.name}: ${account.balance}`);
      return sum + (Number(account.balance) || 0);
    }, 0);
    
    console.log('Saldo total calculado:', totalBalance);
    
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
    const monthTransactions = transactions.filter(t => t.date.startsWith(currentMonth));
    
    const monthlyIncome = monthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    
    const monthlyExpenses = monthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    
    const totalReceived = transactions
      .filter(t => t.type === 'income' && t.status === 'received')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    
    const totalPaid = transactions
      .filter(t => t.type === 'expense' && t.status === 'paid')
      .reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

    const summary = {
      totalBalance,
      monthlyIncome,
      monthlyExpenses,
      totalReceived,
      totalPaid
    };
    
    console.log('Resumo final:', summary);
    return summary;
  }, [accounts, transactions]);

  const addCustomCategory = useCallback((category: Omit<Category, 'id'>) => {
    const newCategory: Category = {
      ...category,
      id: `custom-${Date.now()}`,
      subcategories: []
    };
    setCustomCategories(prev => [...prev, newCategory]);
  }, []);

  const addCustomSubcategory = useCallback((categoryId: string, subcategory: Omit<SubCategory, 'id'>) => {
    const newSubcategory: SubCategory = {
      ...subcategory,
      id: `sub-${Date.now()}`
    };
    
    // Check if it's a default category
    const defaultCategory = defaultCategories.find(cat => cat.id === categoryId);
    if (defaultCategory) {
      // Create a custom version of the default category with the new subcategory
      const customVersion: Category = {
        ...defaultCategory,
        id: `custom-${categoryId}`,
        subcategories: [...defaultCategory.subcategories, newSubcategory]
      };
      setCustomCategories(prev => {
        const filtered = prev.filter(cat => cat.id !== `custom-${categoryId}`);
        return [...filtered, customVersion];
      });
    } else {
      // It's already a custom category
      setCustomCategories(prev => prev.map(cat => 
        cat.id === categoryId 
          ? { ...cat, subcategories: [...cat.subcategories, newSubcategory] }
          : cat
      ));
    }
  }, []);

  const resetAllData = useCallback(() => {
    setAccounts([]);
    setCards([]);
    setTransactions([]);
    setCustomCategories([]);
    setGoals([]);
    setLimits([]);
    
    // Limpar localStorage
    localStorage.removeItem('financial_accounts');
    localStorage.removeItem('financial_cards');
    localStorage.removeItem('financial_transactions');
    localStorage.removeItem('financial_categories');
    localStorage.removeItem('financial_goals');
    localStorage.removeItem('financial_limits');
    
    console.log('Todos os dados foram resetados');
  }, []);

  return {
    accounts,
    cards,
    transactions,
    customCategories,
    goals,
    limits,
    addAccount,
    updateAccount,
    deleteAccount,
    addCard,
    updateCard,
    addTransaction,
    updateTransaction,
    addGoal,
    updateGoal,
    addLimit,
    updateLimit,
    getFinancialSummary,
    addCustomCategory,
    addCustomSubcategory,
    resetAllData
  };
};