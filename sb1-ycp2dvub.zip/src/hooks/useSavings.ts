import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import { SavingsBox, CDIRate, SavingsProjection } from '../types/savings';
import { CDIService } from '../lib/cdi';

export const useSavings = () => {
  const { user } = useAuth();
  const [savingsBoxes, setSavingsBoxes] = useState<SavingsBox[]>([]);
  const [cdiRates, setCdiRates] = useState<CDIRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Carregar caixinhas do usuário
  const loadSavingsBoxes = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('savings_boxes')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSavingsBoxes(data || []);
    } catch (err: any) {
      setError(err.message);
    }
  }, [user]);

  // Carregar taxas CDI
  const loadCDIRates = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('cdi_rates')
        .select('*')
        .order('date', { ascending: false })
        .limit(30); // Últimos 30 registros

      if (error) throw error;
      setCdiRates(data || []);
    } catch (err: any) {
      setError(err.message);
    }
  }, []);

  // Buscar taxa CDI atual online (simulação)
  const fetchCurrentCDI = useCallback(async (): Promise<number> => {
    try {
      // Buscar taxa CDI atual do Banco Central
      const currentRate = await CDIService.fetchCurrentCDIRate();
      
      // Salvar nova taxa no banco se for diferente da última
      const latestRate = cdiRates[0];
      const today = new Date().toISOString().split('T')[0];
      
      if (!latestRate || latestRate.date !== today || Math.abs(latestRate.rate - currentRate) > 0.01) {
        await supabase
          .from('cdi_rates')
          .upsert({
            date: today,
            rate: currentRate,
            source: 'bcb'
          }, { onConflict: 'date' });
        
        // Recarregar taxas
        await loadCDIRates();
      }
      
      return currentRate;
    } catch (error) {
      console.error('Erro ao buscar CDI:', error);
      return 8.25; // Taxa padrão
    }
  }, [cdiRates]);

  // Calcular projeção de rendimento
  const calculateProjection = useCallback((
    initialAmount: number,
    monthlyContribution: number,
    cdiPercentage: number,
    months: number,
    currentCDIRate: number
  ): SavingsProjection => {
    const effectiveAnnualRate = currentCDIRate * cdiPercentage / 100; // Taxa efetiva anual
    return CDIService.calculateCompoundInterest(initialAmount, monthlyContribution, effectiveAnnualRate, months);

  }, []);

  // Adicionar nova caixinha
  const addSavingsBox = useCallback(async (savingsBox: Omit<SavingsBox, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('savings_boxes')
        .insert({
          ...savingsBox,
          user_id: user.id
        })
        .select()
        .single();

      if (error) throw error;
      
      setSavingsBoxes(prev => [data, ...prev]);
      return { data, error: null };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, [user]);

  // Atualizar caixinha
  const updateSavingsBox = useCallback(async (id: string, updates: Partial<SavingsBox>) => {
    try {
      const { data, error } = await supabase
        .from('savings_boxes')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      setSavingsBoxes(prev => prev.map(box => 
        box.id === id ? { ...box, ...data } : box
      ));
      return { data, error: null };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, []);

  // Fazer depósito em caixinha
  const depositToSavingsBox = useCallback(async (id: string, amount: number, description?: string) => {
    if (!user) return;

    try {
      // Buscar caixinha atual
      const { data: currentBox, error: fetchError } = await supabase
        .from('savings_boxes')
        .select('*')
        .eq('id', id)
        .single();

      if (fetchError) throw fetchError;

      // Atualizar saldo
      const newAmount = currentBox.current_amount + amount;
      const { error: updateError } = await supabase
        .from('savings_boxes')
        .update({ current_amount: newAmount })
        .eq('id', id);

      if (updateError) throw updateError;

      // Registrar transação
      const { error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          title: `Depósito - ${currentBox.name}`,
          description: description || `Depósito na caixinha ${currentBox.name}`,
          amount: amount,
          type: 'expense',
          category: 'poupanca',
          subcategory: 'reserva-longo-prazo',
          payment_method: 'account',
          status: 'paid',
          date: new Date().toISOString().split('T')[0]
        });

      if (transactionError) throw transactionError;

      // Atualizar estado local
      setSavingsBoxes(prev => prev.map(box => 
        box.id === id ? { ...box, current_amount: newAmount } : box
      ));

      return { data: { newAmount }, error: null };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, [user]);

  // Deletar caixinha
  const deleteSavingsBox = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('savings_boxes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setSavingsBoxes(prev => prev.filter(box => box.id !== id));
      return { error: null };
    } catch (err: any) {
      setError(err.message);
      return { error: err };
    }
  }, []);

  useEffect(() => {
    if (user) {
      Promise.all([
        loadSavingsBoxes(),
        loadCDIRates()
      ]).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [user, loadSavingsBoxes, loadCDIRates]);

  return {
    savingsBoxes,
    cdiRates,
    loading,
    error,
    addSavingsBox,
    updateSavingsBox,
    depositToSavingsBox,
    deleteSavingsBox,
    fetchCurrentCDI,
    calculateProjection,
    loadSavingsBoxes
  };
};