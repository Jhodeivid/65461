// Este arquivo foi removido - sistema empresarial descontinuado
// Hook empresarial substituído por gestão pessoal apenas

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

interface Profile {
  id: string;
  user_id: string;
  account_type: 'personal';
  full_name?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export const useEnterprise = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Carregar perfil do utilizador (apenas pessoal)
  const loadProfile = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        // Criar perfil se não existir (sempre pessoal)
        const newProfile = {
          user_id: user.id,
          account_type: 'personal' as const,
          full_name: user.user_metadata?.full_name || '',
          avatar_url: user.user_metadata?.avatar_url || ''
        };

        const { data: createdProfile, error: createError } = await supabase
          .from('profiles')
          .upsert([newProfile], { onConflict: 'user_id' })
          .select()
          .single();

        if (createError) throw createError;
        setProfile(createdProfile);
      }
    } catch (err: any) {
      setError(err.message);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      loadProfile();
    }
    setLoading(false);
  }, [user, loadProfile]);

  // Função vazia para compatibilidade
  const updateAccountType = async (accountType: 'personal') => {
    // Sempre pessoal, não faz nada
    return { data: profile, error: null };
  };

  return {
    profile,
    companies: [], // Sempre vazio
    activeCompany: null, // Sempre null
    sales: [], // Sempre vazio
    loading,
    error,
    updateAccountType,
    loadProfile
  };
};