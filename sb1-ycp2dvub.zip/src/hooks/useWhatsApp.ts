import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';
import { WhatsAppUser, WhatsAppMessage } from '../types/savings';

export const useWhatsApp = () => {
  const { user } = useAuth();
  const [whatsappUser, setWhatsappUser] = useState<WhatsAppUser | null>(null);
  const [messages, setMessages] = useState<WhatsAppMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Carregar dados do WhatsApp do usuário
  const loadWhatsAppData = useCallback(async () => {
    if (!user) return;

    try {
      // Carregar dados do usuário WhatsApp
      const { data: whatsappData, error: whatsappError } = await supabase
        .from('whatsapp_users')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (whatsappError && whatsappError.code !== 'PGRST116') {
        throw whatsappError;
      }

      setWhatsappUser(whatsappData);

      // Carregar mensagens recentes
      const { data: messagesData, error: messagesError } = await supabase
        .from('whatsapp_messages')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (messagesError) throw messagesError;
      setMessages(messagesData || []);

    } catch (err: any) {
      setError(err.message);
    }
  }, [user]);

  // Conectar número do WhatsApp
  const connectWhatsApp = useCallback(async (phoneNumber: string, whatsappNumber: string) => {
    if (!user) return { data: null, error: { message: 'Usuário não autenticado' } };

    try {
      // Gerar código de verificação
      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutos

      const { data, error } = await supabase
        .from('whatsapp_users')
        .upsert({
          user_id: user.id,
          phone_number: phoneNumber,
          whatsapp_number: whatsappNumber,
          is_verified: false,
          verification_code: verificationCode,
          verification_expires_at: expiresAt.toISOString()
        }, { onConflict: 'user_id' })
        .select()
        .single();

      if (error) throw error;

      setWhatsappUser(data);
      
      // Aqui você enviaria o código via WhatsApp
      // Por enquanto, apenas retornamos o código para teste
      return { 
        data: { 
          ...data, 
          verification_code: verificationCode 
        }, 
        error: null 
      };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, [user]);

  // Verificar código do WhatsApp
  const verifyWhatsApp = useCallback(async (code: string) => {
    if (!user || !whatsappUser) return { data: null, error: { message: 'Dados insuficientes' } };

    try {
      // Verificar se o código está correto e não expirou
      const now = new Date();
      const expiresAt = new Date(whatsappUser.verification_expires_at || '');

      if (now > expiresAt) {
        throw new Error('Código de verificação expirado');
      }

      if (code !== whatsappUser.verification_code) {
        throw new Error('Código de verificação inválido');
      }

      // Marcar como verificado
      const { data, error } = await supabase
        .from('whatsapp_users')
        .update({
          is_verified: true,
          verification_code: null,
          verification_expires_at: null
        })
        .eq('id', whatsappUser.id)
        .select()
        .single();

      if (error) throw error;

      setWhatsappUser(data);
      return { data, error: null };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, [user, whatsappUser]);

  // Desconectar WhatsApp
  const disconnectWhatsApp = useCallback(async () => {
    if (!user || !whatsappUser) return;

    try {
      const { error } = await supabase
        .from('whatsapp_users')
        .delete()
        .eq('id', whatsappUser.id);

      if (error) throw error;

      setWhatsappUser(null);
      setMessages([]);
    } catch (err: any) {
      setError(err.message);
    }
  }, [user, whatsappUser]);

  // Simular envio de mensagem de teste
  const sendTestMessage = useCallback(async (message: string) => {
    if (!user || !whatsappUser?.is_verified) {
      return { data: null, error: { message: 'WhatsApp não conectado ou verificado' } };
    }

    try {
      // Simular processamento da mensagem
      const { data, error } = await supabase.functions.invoke('whatsapp-processor', {
        body: {
          object: 'whatsapp_business_account',
          entry: [{
            changes: [{
              value: {
                messages: [{
                  from: whatsappUser.whatsapp_number,
                  text: { body: message }
                }]
              }
            }]
          }]
        }
      });

      if (error) throw error;

      // Recarregar mensagens
      await loadWhatsAppData();

      return { data, error: null };
    } catch (err: any) {
      setError(err.message);
      return { data: null, error: err };
    }
  }, [user, whatsappUser, loadWhatsAppData]);

  useEffect(() => {
    if (user) {
      loadWhatsAppData().finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [user, loadWhatsAppData]);

  return {
    whatsappUser,
    messages,
    loading,
    error,
    connectWhatsApp,
    verifyWhatsApp,
    disconnectWhatsApp,
    sendTestMessage,
    loadWhatsAppData
  };
};