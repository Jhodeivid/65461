import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { useRealtimeUpdates } from '../hooks/useRealtimeUpdates';
import { PersonalDashboard } from './PersonalDashboard';
import { AuthForm } from './AuthForm';

const ResponsiveFinancialModule: React.FC = () => {
  const { user, loading } = useAuth();
  
  // Configurar atualizações em tempo real
  useRealtimeUpdates({
    onTransactionUpdate: (payload) => {
      console.log('Nova transação via WhatsApp:', payload.new);
      // Forçar atualização da interface se necessário
      window.dispatchEvent(new CustomEvent('financial-data-updated'));
    },
    onSavingsUpdate: (payload) => {
      console.log('Caixinha atualizada via WhatsApp:', payload.new);
      window.dispatchEvent(new CustomEvent('savings-data-updated'));
    },
    onWhatsAppMessage: (payload) => {
      console.log('Nova mensagem WhatsApp processada:', payload.new);
    }
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  // Se o usuário não está logado, mostrar login
  if (!user) {
    return <AuthForm />;
  }

  // Se o usuário está logado, mostrar dashboard pessoal
  return <PersonalDashboard />;
};

export default ResponsiveFinancialModule;