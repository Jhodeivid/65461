import React, { useState } from 'react';
import { MessageCircle, Smartphone, Shield, CheckCircle, AlertTriangle, Send, Phone, QrCode, Zap, Settings, ExternalLink } from 'lucide-react';
import { useWhatsApp } from '../hooks/useWhatsApp';
import { useApp } from '../contexts/AppContext';
import { WhatsAppSetup } from './WhatsAppSetup';

export const WhatsAppIntegration: React.FC = () => {
  const [showAdvancedSetup, setShowAdvancedSetup] = useState(false);

  return (
    <div>
      {showAdvancedSetup ? (
        <WhatsAppSetup />
      ) : (
        <div className="space-y-8">
          {/* Header com opção de setup avançado */}
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-2xl">
                  <MessageCircle className="h-8 w-8 text-white" />
                </div>
                Integração WhatsApp
              </h2>
              <p className="text-gray-600 mt-2">Gerencie suas finanças diretamente pelo WhatsApp</p>
            </div>
            <button
              onClick={() => setShowAdvancedSetup(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
            >
              <Settings className="h-5 w-5" />
              Setup Completo
            </button>
          </div>

          {/* Aviso sobre configuração necessária */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-6">
            <div className="flex items-center gap-4">
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-3 rounded-full">
                <AlertTriangle className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-bold text-blue-900 mb-2">⚙️ Configuração Necessária</h3>
                <p className="text-blue-800 mb-3">
                  Para ativar a automação WhatsApp, você precisa configurar:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-700">
                  <div className="space-y-1">
                    <p>• ✅ Supabase Edge Function (já criada)</p>
                    <p>• ✅ Banco de dados (já configurado)</p>
                    <p>• ✅ Interface de usuário (pronta)</p>
                  </div>
                  <div className="space-y-1">
                    <p>• ⚠️ Meta for Developers (configurar)</p>
                    <p>• ⚠️ WhatsApp Business API (configurar)</p>
                    <p>• ⚠️ Variáveis de ambiente (configurar)</p>
                  </div>
                </div>
              </div>
              <div className="flex-shrink-0">
                <button
                  onClick={() => setShowAdvancedSetup(true)}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  Ver Guia Completo
                </button>
              </div>
            </div>
          </div>

          {/* Demonstração do Sistema */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-full">
                <Zap className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">Como Funcionará</h3>
                <p className="text-gray-600">Demonstração do fluxo de automação</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-xl border border-blue-200 text-center">
                <div className="text-3xl mb-3">📱</div>
                <h4 className="font-bold text-blue-900 mb-2">1. Enviar</h4>
                <p className="text-blue-800 text-sm">
                  "gastei 50 no supermercado"
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-xl border border-purple-200 text-center">
                <div className="text-3xl mb-3">🤖</div>
                <h4 className="font-bold text-purple-900 mb-2">2. IA Processa</h4>
                <p className="text-purple-800 text-sm">
                  Sofia analisa e categoriza automaticamente
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-xl border border-green-200 text-center">
                <div className="text-3xl mb-3">💾</div>
                <h4 className="font-bold text-green-900 mb-2">3. Salvar</h4>
                <p className="text-green-800 text-sm">
                  Dados salvos no Supabase automaticamente
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-4 rounded-xl border border-yellow-200 text-center">
                <div className="text-3xl mb-3">✅</div>
                <h4 className="font-bold text-yellow-900 mb-2">4. Confirmar</h4>
                <p className="text-yellow-800 text-sm">
                  Confirmação automática via WhatsApp
                </p>
              </div>
            </div>
          </div>

          {/* Recursos Disponíveis */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-green-900">Recursos Disponíveis</h3>
                <p className="text-green-700">O que você poderá fazer via WhatsApp</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-4 rounded-xl border border-green-200">
                <h4 className="font-bold text-green-900 mb-3">💰 Transações</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li>• Registrar despesas: "gastei 50 no supermercado"</li>
                  <li>• Registrar receitas: "recebi 1200 de salário"</li>
                  <li>• Categorização automática inteligente</li>
                  <li>• Detecção de local e tipo de gasto</li>
                </ul>
              </div>
              
              <div className="bg-white p-4 rounded-xl border border-green-200">
                <h4 className="font-bold text-green-900 mb-3">🐷 Caixinhas</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li>• Criar caixinhas: "criar caixinha viagem 5000"</li>
                  <li>• Fazer depósitos: "depositar 200 na caixinha viagem"</li>
                  <li>• Consultar saldos: "saldo das caixinhas"</li>
                  <li>• Acompanhar progresso das metas</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center bg-gradient-to-r from-purple-600 to-pink-600 text-white p-8 rounded-2xl">
            <div className="text-5xl mb-4">🚀</div>
            <h3 className="text-2xl font-bold mb-2">Pronto para Automatizar?</h3>
            <p className="text-purple-100 mb-6 max-w-2xl mx-auto">
              Siga o guia completo de configuração e transforme a forma como você gerencia suas finanças!
            </p>
            <button
              onClick={() => setShowAdvancedSetup(true)}
              className="bg-white text-purple-600 hover:bg-purple-50 px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
            >
              Começar Configuração
            </button>
          </div>
        </div>
      )}
    </div>
  );
};