import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, X, Sparkles, Bot, User, Loader, AlertTriangle } from 'lucide-react';
import { openai } from '../lib/openai';
import { Transaction, Account, Card, Goal, Limit } from '../types/financial';
import { Category, defaultCategories } from '../data/categories';
import { useApp } from '../contexts/AppContext';

interface AIChatProps {
  onAddTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  onAddCustomSubcategory: (categoryId: string, subcategory: Omit<import('../data/categories').SubCategory, 'id'>) => void;
  onAddAccount: (account: Omit<Account, 'id'>) => void;
  onAddCard: (card: Omit<Card, 'id'>) => void;
  onAddGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  onAddLimit: (limit: Omit<Limit, 'id' | 'createdAt' | 'resetDate'>) => void;
  onResetAllData: () => void;
  customCategories: Category[];
  accounts: Account[];
  cards: Card[];
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  isProcessing?: boolean;
}

export const AIChat: React.FC<AIChatProps> = ({
  onAddTransaction,
  onAddCustomSubcategory,
  onAddAccount,
  onAddCard,
  onAddGoal,
  onAddLimit,
  onResetAllData,
  customCategories,
  accounts,
  cards
}) => {
  const { formatCurrency } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: '👋 Olá! Sou a Sofia, sua assistente financeira inteligente. Posso ajudá-lo a:\n\n• Registar transações (ex: "gastei 50€ no supermercado")\n• Criar contas bancárias (ex: "criar conta Nubank corrente saldo 1000")\n• Adicionar cartões (ex: "adicionar cartão Nubank limite 2000 vence dia 5 fecha dia 1")\n• Definir metas financeiras\n• Configurar limites de gastos\n• Fazer transferências entre contas\n\n⚠️ **Importante**: Se mencionar uma receita para uma conta que não existe, perguntarei se deseja criá-la primeiro!\n\nComo posso ajudá-lo hoje?',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const processAICommand = async (command: any) => {
    try {
      console.log('Processando comando da IA:', command);
      
      switch (command.action) {
        case 'CREATE_TRANSACTION':
          // Verificar se a conta mencionada existe (para receitas)
          if (command.data.type === 'income' && command.data.payment_method === 'account' && command.data.payment_source) {
            const accountExists = accounts.find(acc => 
              acc.id === command.data.payment_source || 
              acc.name.toLowerCase().includes(command.data.payment_source.toLowerCase())
            );
            if (!accountExists) {
              return `❌ **Erro de Processamento**: A conta "${command.data.payment_source}" não foi encontrada.\n\n🤖 **Nota da IA**: Este comando deveria ter sido interceptado antes. Por favor, tente novamente mencionando a conta específica.`;
            }
          }
          
          // Verificar saldo insuficiente para transferências
          if (command.data.type === 'transfer' && command.data.transfer_from_account) {
            const fromAccount = accounts.find(acc => 
              acc.id === command.data.transfer_from_account || 
              acc.name.toLowerCase().includes(command.data.transfer_from_account.toLowerCase())
            );
            if (fromAccount && command.data.amount > fromAccount.balance) {
              return `❌ **Saldo insuficiente**: A conta "${fromAccount.name}" tem apenas ${formatCurrency(fromAccount.balance)} disponível.\n\n💡 **Sugestão**: Reduza o valor da transferência ou escolha outra conta de origem.`;
            }
          }
          
          const transactionData = {
            title: command.data.title,
            description: command.data.description || '',
            amount: command.data.amount,
            type: command.data.type as 'income' | 'expense' | 'transfer',
            category: command.data.category,
            subcategory: command.data.subcategory,
            paymentMethod: command.data.payment_method as 'account' | 'card' | 'cash' | 'pix',
            paymentSource: command.data.payment_source,
            status: command.data.status as 'paid' | 'received' | 'pending',
            date: command.data.date || new Date().toISOString().split('T')[0]
          };
          console.log('Dados da transação:', transactionData);
          onAddTransaction(transactionData);
          return `✅ **Transação registada com sucesso!**\n\n${command.data.type === 'income' ? 'Receita' : 'Despesa'} de ${command.data.amount.toFixed(2)}€ - ${command.data.title}\nCategoria: ${command.category} ${command.subcategory ? `> ${command.subcategory}` : ''}`;

        case 'CREATE_ACCOUNT':
          const accountData = {
            name: command.data.name,
            balance: command.data.initial_balance || 0,
            type: command.data.account_type as 'checking' | 'savings' | 'investment',
            bank: command.data.bank_name
          };
          console.log('Dados da conta:', accountData);
          onAddAccount(accountData);
          return `✅ **Conta criada com sucesso!**\n\n${accountData.name}\nSaldo inicial: ${accountData.balance.toFixed(2)}€\nTipo: ${accountData.type === 'checking' ? 'Conta Corrente' : accountData.type === 'savings' ? 'Conta Poupança' : 'Conta Investimento'}`;

        case 'CREATE_CARD':
          const cardData = {
            name: command.data.name,
            limit: command.data.credit_limit || command.data.limit || 0,
            used: command.data.used_amount || 0,
            type: command.data.card_type as 'credit' | 'debit',
            bank: command.data.bank_name,
            dueDate: command.data.due_day?.toString(),
            closingDate: command.data.closing_day?.toString()
          };
          console.log('Dados do cartão:', cardData);
          onAddCard(cardData);
          return `✅ **Cartão adicionado com sucesso!**\n\n${cardData.name}\nLimite: ${cardData.limit.toFixed(2)}€\nTipo: ${cardData.type === 'credit' ? 'Cartão de Crédito' : 'Cartão de Débito'}${cardData.dueDate ? `\nVencimento: dia ${cardData.dueDate}` : ''}${cardData.closingDate ? `\nFechamento: dia ${cardData.closingDate}` : ''}`;

        case 'CREATE_GOAL':
          const goalData = {
            title: command.data.title,
            description: command.data.description,
            targetAmount: command.data.target_amount,
            currentAmount: command.data.current_amount || 0,
            monthlyContribution: command.data.monthly_contribution || 0,
            targetDate: command.data.target_date,
            category: command.data.category,
            priority: command.data.priority as 'low' | 'medium' | 'high',
            status: 'active' as const
          };
          console.log('Dados da meta:', goalData);
          onAddGoal(goalData);
          return `✅ **Meta criada com sucesso!**\n\n${goalData.title}\nObjetivo: ${goalData.targetAmount.toFixed(2)}€\nContribuição mensal: ${goalData.monthlyContribution.toFixed(2)}€`;

        case 'CREATE_LIMIT':
          const limitData = {
            title: command.data.title,
            category: command.data.category,
            subcategory: command.data.subcategory,
            limitAmount: command.data.limit_amount,
            currentAmount: 0,
            period: command.data.period as 'monthly' | 'biweekly' | 'bimonthly' | 'quarterly' | 'semiannual' | 'annual',
            alertThreshold: command.data.alert_threshold || 80,
            isActive: true,
            startDate: command.data.start_date || new Date().toISOString().split('T')[0],
            startType: command.data.start_type as 'today' | 'first_day' | 'last_day'
          };
          console.log('Dados do limite:', limitData);
          onAddLimit(limitData);
          return `✅ **Limite criado com sucesso!**\n\n${limitData.title}\nValor: ${limitData.limitAmount.toFixed(2)}€\nPeríodo: ${limitData.period}`;

        case 'CREATE_SAVINGS_BOX':
          // Usar o hook de savings se disponível
          if (command.data.name && command.data.target_amount) {
            // Esta funcionalidade será integrada com o sistema de caixinhas
            return `✅ **Caixinha criada com sucesso!**\n\n${command.data.name}\nMeta: ${formatCurrency(command.data.target_amount)}\nBanco: ${command.data.bank_name || 'Nubank'}`;
          }
          return `❌ **Erro:** Dados insuficientes para criar caixinha.`;

        case 'DEPOSIT_SAVINGS':
          if (command.data.savings_box_name && command.data.amount) {
            return `✅ **Depósito realizado!**\n\nR$ ${command.data.amount.toFixed(2)} → Caixinha ${command.data.savings_box_name}`;
          }
          return `❌ **Erro:** Dados insuficientes para depósito.`;

        case 'QUERY_SAVINGS':
          return `📊 **Consultando suas caixinhas...**\n\nEsta funcionalidade está sendo processada.`;

        case 'RESET_DATA':
          onResetAllData();
          return `✅ **Dados resetados com sucesso!**\n\nTodos os seus dados financeiros foram limpos.`;

        case 'ASK_CREATE_ACCOUNT':
          // Armazenar a transação pendente para processar após criação da conta
          if (command.data.pending_transaction) {
            // Aqui você poderia armazenar temporariamente a transação pendente
            // Por simplicidade, vamos apenas informar ao usuário
            return `🤔 **Conta não encontrada**: A conta "${command.data.account_name}" não está registada no seu sistema.\n\n❓ **Deseja criá-la agora?**\n\nSe confirmar, criarei a conta e depois adicionarei a ${command.data.pending_transaction.type === 'income' ? 'receita' : 'despesa'} de ${formatCurrency(command.data.pending_transaction.amount)}.\n\n**Opções:**\n• Responda "sim" para Conta Corrente\n• "criar conta ${command.data.account_name} poupança"\n• "criar conta ${command.data.account_name} investimento"`;
          }
          return `🤔 **Conta não encontrada**: A conta "${command.data.account_name}" não existe.\n\n❓ **Deseja criá-la agora?**\n\nResponda "sim" para criar como Conta Corrente com saldo inicial de 0€.`;
          
        case 'ERROR':
          if (command.data?.error_type === 'insufficient_balance') {
            return `❌ **Saldo insuficiente**: A ${command.data.from_account} tem apenas ${formatCurrency(command.data.available_balance)} disponível para esta transferência de ${formatCurrency(command.data.requested_amount)}.\n\n💡 **Sugestões:**\n• Reduza o valor para ${formatCurrency(command.data.available_balance)} ou menos\n• Escolha outra conta de origem\n• Adicione fundos à conta antes da transferência`;
          }
          return `❌ **Erro:** ${command.message || 'Ocorreu um erro inesperado.'}`;

        default:
          return command.message || 'Comando processado.';
      }
    } catch (error) {
      console.error('Erro ao processar comando da IA:', error);
      return `❌ **Erro:** Não foi possível processar o comando. Tente novamente.`;
    }
  };

  const sendMessage = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    // Adicionar mensagem de processamento
    const processingMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: 'Processando seu pedido...',
      sender: 'ai',
      timestamp: new Date(),
      isProcessing: true
    };

    setMessages(prev => [...prev, processingMessage]);

    try {
      if (!import.meta.env.VITE_OPENAI_API_KEY) {
        // Remover mensagem de processamento e adicionar aviso sobre API key
        setMessages(prev => {
          const filtered = prev.filter(msg => !msg.isProcessing);
          return [...filtered, {
            id: Date.now().toString(),
            text: `⚠️ **Funcionalidade Temporariamente Indisponível**\n\nA IA Sofia está temporariamente indisponível porque a chave da API OpenAI não está configurada.\n\n**Como usar mesmo assim:**\n• Digite comandos como: "gastei 50€ no supermercado"\n• Ou: "criar conta Nubank saldo 1000€"\n• Ou: "adicionar cartão limite 2000€"\n\nO sistema tentará processar automaticamente seus comandos básicos.`,
            sender: 'ai',
            timestamp: new Date()
          }];
        });
        setIsLoading(false);
        return;
      }

      const systemPrompt = `
Você é a Sofia, uma assistente financeira inteligente que processa comandos em português e retorna SEMPRE em formato JSON válido.

REGRAS CRÍTICAS:
1. SEMPRE responda em JSON válido
2. Identifique automaticamente categorias baseadas no contexto
3. Para contas: use "CREATE_ACCOUNT" 
4. Para cartões: use "CREATE_CARD"
5. Para transações: use "CREATE_TRANSACTION"
6. VERIFICAÇÃO DE CONTAS OBRIGATÓRIA: Se uma receita menciona uma conta específica, SEMPRE verifique se ela existe primeiro
7. VALIDAÇÃO DE TRANSFERÊNCIAS OBRIGATÓRIA: Para transferências, SEMPRE verifique se há saldo suficiente na conta de origem
8. CRIAÇÃO IMPLÍCITA DE CONTAS: Se uma conta não existir, ofereça criá-la automaticamente

CATEGORIAS DISPONÍVEIS: ${defaultCategories.map(cat => `${cat.id}: ${cat.name}`).join(', ')}

CONTAS EXISTENTES: ${accounts.map(acc => `${acc.name} (${formatCurrency(acc.balance)})`).join(', ')}

FLUXO OBRIGATÓRIO PARA RECEITAS EM CONTAS ESPECÍFICAS:
1. Verificar se a conta mencionada existe
2. Se NÃO existir: usar "ASK_CREATE_ACCOUNT" 
3. Se existir: prosseguir com "CREATE_TRANSACTION"

FLUXO OBRIGATÓRIO PARA TRANSFERÊNCIAS:
1. Verificar se ambas as contas existem
2. Verificar se há saldo suficiente na conta de origem
3. Se saldo insuficiente: usar "ERROR" com mensagem específica
4. Se tudo OK: prosseguir com "CREATE_TRANSACTION"

EXEMPLOS DE COMANDOS:

Para "criar conta nubank corrente saldo 1000":
{
  "action": "CREATE_ACCOUNT",
  "data": {
    "name": "Nubank - Conta Corrente",
    "bank_name": "nubank",
    "account_type": "checking",
    "initial_balance": 1000.00
  },
  "message": "✅ Conta Nubank criada com saldo de 1000€!",
  "confidence": 0.95
}

Para "adicionar cartão nubank limite 2000 vence dia 5 fecha dia 1":
{
  "action": "CREATE_CARD",
  "data": {
    "name": "Nubank - Cartão de Crédito",
    "bank_name": "nubank",
    "card_type": "credit",
    "limit": 2000.00,
    "used_amount": 0,
    "due_day": 5,
    "closing_day": 1
  },
  "message": "✅ Cartão Nubank adicionado com limite de 2000€!",
  "confidence": 0.95
}

Para "gastei 50 no supermercado":
{
  "action": "CREATE_TRANSACTION",
  "data": {
    "type": "expense",
    "amount": 50.00,
    "title": "Supermercado",
    "description": "Compra no supermercado",
    "category": "alimentacao",
    "subcategory": "supermercado",
    "payment_method": "cash",
    "status": "paid",
    "date": "${new Date().toISOString().split('T')[0]}"
  },
  "message": "✅ Despesa de 50€ no supermercado registada!",
  "category": "alimentacao",
  "subcategory": "supermercado",
  "confidence": 0.95
}

Para "recebi 1000€ na conta XYZ" (QUANDO A CONTA NÃO EXISTE - OBRIGATÓRIO):
{
  "action": "ASK_CREATE_ACCOUNT",
  "data": {
    "account_name": "XYZ",
    "suggested_type": "checking",
    "suggested_balance": 0,
    "pending_transaction": {
      "type": "income",
      "amount": 1000.00,
      "title": "Receita",
      "description": "Receita na conta XYZ",
      "category": "renda",
      "subcategory": "salarios"
    }
  },
  "message": "🤔 **Conta não encontrada**: A conta 'XYZ' não está registada no seu sistema.\\n\\n❓ **Deseja criá-la agora?**\\n\\nResponda 'sim' para criar como Conta Corrente com saldo inicial de 0€, ou especifique o tipo e saldo inicial.",
  "confidence": 0.90
}

Para "transferir 500€ da conta A para conta B" (QUANDO SALDO INSUFICIENTE - OBRIGATÓRIO):
{
  "action": "ERROR",
  "data": {
    "error_type": "insufficient_balance",
    "from_account": "conta A",
    "requested_amount": 500.00,
    "available_balance": 200.00
  },
  "message": "❌ **Saldo insuficiente**: A conta A tem apenas 200€ disponível para esta transferência de 500€.\\n\\n💡 **Sugestão**: Reduza o valor da transferência ou escolha outra conta de origem.",
  "confidence": 0.95
}

Para "recebi 1000€ na conta Nubank" (QUANDO A CONTA EXISTE):
{
  "action": "CREATE_TRANSACTION",
  "data": {
    "type": "income",
    "amount": 1000.00,
    "title": "Receita",
    "description": "Receita na conta Nubank",
    "category": "renda",
    "subcategory": "salarios",
    "payment_method": "account",
    "payment_source": "ACCOUNT_ID_NUBANK",
    "status": "received",
    "date": "${new Date().toISOString().split('T')[0]}"
  },
  "message": "✅ Receita de 1000€ registada na conta Nubank!",
  "confidence": 0.95
}

IMPORTANTE: Sempre retorne JSON válido e identifique corretamente se é conta, cartão ou transação.
CRÍTICO: SEMPRE verifique a existência de contas e saldos antes de processar transações. Esta verificação é OBRIGATÓRIA.
`;

      const response = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: inputText }
        ],
        temperature: 0.3,
        max_tokens: 500
      });

      const aiResponse = response.choices[0]?.message?.content;
      
      if (!aiResponse) {
        throw new Error('Resposta vazia da IA');
      }

      // Tentar parsear como JSON
      let command;
      try {
        command = JSON.parse(aiResponse);
      } catch (parseError) {
        // Se não for JSON válido, tratar como texto simples
        command = {
          action: 'ERROR',
          message: aiResponse
        };
      }

      // Processar o comando
      const resultMessage = await processAICommand(command);

      setMessages(prev => {
        const filtered = prev.filter(msg => !msg.isProcessing);
        return [...filtered, {
          id: Date.now().toString(),
          text: resultMessage,
          sender: 'ai',
          timestamp: new Date()
        }];
      });

    } catch (error: any) {
      console.error('Erro na IA:', error);
      
      setMessages(prev => {
        const filtered = prev.filter(msg => !msg.isProcessing);
        return [...filtered, {
          id: Date.now().toString(),
          text: `❌ **Erro:** ${error.message || 'Não foi possível processar sua solicitação. Verifique se a chave da API OpenAI está configurada corretamente.'}\n\n**Processamento Local Ativado**\n\nVou tentar processar seu comando localmente:\n\n${tryLocalProcessing(inputText)}`,
          sender: 'ai',
          timestamp: new Date()
        }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Função para processar comandos localmente quando a API não está disponível
  const tryLocalProcessing = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    // Detectar menção de conta específica em receitas
    if (lowerInput.includes('recebi') || lowerInput.includes('ganhei')) {
      const accountMatch = input.match(/(?:na conta|conta)\s+([a-zA-Z0-9\s]+)/i);
      if (accountMatch) {
        const mentionedAccount = accountMatch[1].trim();
        const accountExists = accounts.find(acc => 
          acc.name.toLowerCase().includes(mentionedAccount.toLowerCase())
        );
        
        if (!accountExists) {
          return `🤔 **Conta não encontrada**: A conta "${mentionedAccount}" não está registada no seu sistema.\n\n❓ **Deseja criá-la agora?**\n\nSe confirmar, criarei a conta e depois adicionarei a receita.\n\n**Opções:**\n• Responda "sim" para Conta Corrente\n• "criar conta ${mentionedAccount} poupança"\n• "criar conta ${mentionedAccount} investimento"`;
        }
      }
    }
    
    // Detectar transferências e validar saldo
    if (lowerInput.includes('transferir') || lowerInput.includes('transferência')) {
      const amountMatch = input.match(/(\d+(?:[.,]\d{2})?)/);
      const fromAccountMatch = input.match(/(?:da conta|de)\s+([a-zA-Z0-9\s]+?)(?:\s+para|\s+da)/i);
      
      if (amountMatch && fromAccountMatch) {
        const amount = parseFloat(amountMatch[1].replace(',', '.'));
        const fromAccountName = fromAccountMatch[1].trim();
        const fromAccount = accounts.find(acc => 
          acc.name.toLowerCase().includes(fromAccountName.toLowerCase())
        );
        
        if (fromAccount && amount > fromAccount.balance) {
          return `❌ **Saldo insuficiente**: A conta "${fromAccount.name}" tem apenas ${formatCurrency(fromAccount.balance)} disponível para esta transferência de ${formatCurrency(amount)}.\n\n💡 **Sugestões:**\n• Reduza o valor para ${formatCurrency(fromAccount.balance)} ou menos\n• Escolha outra conta de origem\n• Adicione fundos à conta antes da transferência`;
        }
      }
    }
    
    // Detectar transações
    if (lowerInput.includes('gastei') || lowerInput.includes('paguei') || lowerInput.includes('comprei')) {
      const amountMatch = input.match(/(\d+(?:[.,]\d{2})?)/);
      if (amountMatch) {
        const amount = parseFloat(amountMatch[1].replace(',', '.'));
        let category = 'outros';
        let subcategory = '';
        let title = 'Despesa';
        
        // Detectar categoria baseada no texto
        if (lowerInput.includes('supermercado') || lowerInput.includes('mercado')) {
          category = 'alimentacao';
          subcategory = 'supermercado';
          title = 'Supermercado';
        } else if (lowerInput.includes('padaria')) {
          category = 'alimentacao';
          subcategory = 'padaria';
          title = 'Padaria';
        } else if (lowerInput.includes('restaurante') || lowerInput.includes('comida')) {
          category = 'alimentacao';
          subcategory = 'restaurante-delivery';
          title = 'Restaurante';
        } else if (lowerInput.includes('gasolina') || lowerInput.includes('combustível')) {
          category = 'transporte';
          subcategory = 'manutencao-carro';
          title = 'Combustível';
        } else if (lowerInput.includes('farmácia') || lowerInput.includes('remédio')) {
          category = 'saude-bem-estar';
          subcategory = 'farmacia-medicamentos';
          title = 'Farmácia';
        }
        
        try {
          onAddTransaction({
            title,
            description: input,
            amount,
            type: 'expense',
            category,
            subcategory,
            paymentMethod: 'cash',
            status: 'paid',
            date: new Date().toISOString().split('T')[0]
          });
          
          console.log('Transação local processada:', { title, amount, category, subcategory });
          return `✅ **Transação registrada com sucesso!**\n\nDespesa de €${amount.toFixed(2)} - ${title}\nCategoria: ${category}${subcategory ? ` > ${subcategory}` : ''}`;
        } catch (error) {
          console.error('Erro ao registrar transação local:', error);
          return `❌ Erro ao registrar transação: ${error}`;
        }
      }
    }
    
    // Detectar receitas
    if (lowerInput.includes('recebi') || lowerInput.includes('salário') || lowerInput.includes('renda')) {
      const amountMatch = input.match(/(\d+(?:[.,]\d{2})?)/);
      if (amountMatch) {
        const amount = parseFloat(amountMatch[1].replace(',', '.'));
        let title = 'Receita';
        
        if (lowerInput.includes('salário')) {
          title = 'Salário';
        }
        
        try {
          onAddTransaction({
            title,
            description: input,
            amount,
            type: 'income',
            category: 'renda',
            subcategory: 'salarios',
            paymentMethod: 'account',
            status: 'received',
            date: new Date().toISOString().split('T')[0]
          });
          
          console.log('Receita local processada:', { title, amount });
          return `✅ **Receita registrada com sucesso!**\n\nReceita de €${amount.toFixed(2)} - ${title}`;
        } catch (error) {
          console.error('Erro ao registrar receita local:', error);
          return `❌ Erro ao registrar receita: ${error}`;
        }
      }
    }
    
    // Detectar criação de conta
    if (lowerInput.includes('criar conta') || lowerInput.includes('adicionar conta')) {
      const amountMatch = input.match(/(\d+(?:[.,]\d{2})?)/);
      let bankName = 'Outros';
      
      if (lowerInput.includes('nubank')) bankName = 'Nubank';
      else if (lowerInput.includes('itau') || lowerInput.includes('itaú')) bankName = 'Itaú';
      else if (lowerInput.includes('bradesco')) bankName = 'Bradesco';
      else if (lowerInput.includes('santander')) bankName = 'Santander';
      
      const accountType = lowerInput.includes('poupança') ? 'savings' : 
                         lowerInput.includes('investimento') ? 'investment' : 'checking';
      
      try {
        onAddAccount({
          name: `${bankName} - ${accountType === 'checking' ? 'Conta Corrente' : accountType === 'savings' ? 'Poupança' : 'Investimento'}`,
          balance: amountMatch ? parseFloat(amountMatch[1].replace(',', '.')) : 0,
          type: accountType,
          bank: bankName.toLowerCase()
        });
        
        console.log('Conta local processada:', { bankName, accountType, balance: amountMatch ? parseFloat(amountMatch[1].replace(',', '.')) : 0 });
        return `✅ **Conta criada com sucesso!**\n\n${bankName} - ${accountType === 'checking' ? 'Conta Corrente' : accountType === 'savings' ? 'Poupança' : 'Investimento'}\nSaldo inicial: €${amountMatch ? parseFloat(amountMatch[1].replace(',', '.')).toFixed(2) : '0.00'}`;
      } catch (error) {
        console.error('Erro ao criar conta local:', error);
        return `❌ Erro ao criar conta: ${error}`;
      }
    }
    
    // Detectar criação de cartão
    if (lowerInput.includes('criar cartão') || lowerInput.includes('adicionar cartão')) {
      const amountMatch = input.match(/limite\s*(\d+(?:[.,]\d{2})?)/i);
      let bankName = 'Outros';
      
      if (lowerInput.includes('nubank')) bankName = 'Nubank';
      else if (lowerInput.includes('itau') || lowerInput.includes('itaú')) bankName = 'Itaú';
      else if (lowerInput.includes('bradesco')) bankName = 'Bradesco';
      else if (lowerInput.includes('santander')) bankName = 'Santander';
      
      const cardType = lowerInput.includes('débito') ? 'debit' : 'credit';
      
      try {
        onAddCard({
          name: `${bankName} - ${cardType === 'credit' ? 'Cartão de Crédito' : 'Cartão de Débito'}`,
          limit: amountMatch ? parseFloat(amountMatch[1].replace(',', '.')) : 1000,
          used: 0,
          type: cardType,
          bank: bankName.toLowerCase()
        });
        
        console.log('Cartão local processado:', { bankName, cardType, limit: amountMatch ? parseFloat(amountMatch[1].replace(',', '.')) : 1000 });
        return `✅ **Cartão adicionado com sucesso!**\n\n${bankName} - ${cardType === 'credit' ? 'Cartão de Crédito' : 'Cartão de Débito'}\nLimite: €${amountMatch ? parseFloat(amountMatch[1].replace(',', '.')).toFixed(2) : '1000.00'}`;
      } catch (error) {
        console.error('Erro ao criar cartão local:', error);
        return `❌ Erro ao criar cartão: ${error}`;
      }
    }
    
    return `🤖 **Comando não reconhecido**\n\nTente comandos como:\n• "gastei 50€ no supermercado"\n• "recebi 1200€ de salário"\n• "criar conta Nubank saldo 1000€"\n• "adicionar cartão Nubank limite 2000€"`;
  };
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-52 right-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300 z-40 animate-pulse"
      >
        <MessageCircle className="h-6 w-6" />
      </button>

      {/* Chat Modal */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end lg:items-center justify-center lg:justify-end z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md h-[600px] flex flex-col animate-slideIn">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 rounded-t-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white bg-opacity-20 p-2 rounded-full">
                  <Bot className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Sofia IA</h3>
                  <p className="text-white text-opacity-80 text-sm">Assistente Financeira</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white hover:bg-opacity-20 p-2 rounded-full transition-all duration-200"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex items-start gap-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`p-2 rounded-full ${
                      message.sender === 'user'
                        ? 'bg-blue-600' 
                        : message.isProcessing 
                        ? 'bg-yellow-500' 
                        : 'bg-purple-600'
                    }`}>
                      {message.sender === 'user' ? (
                        <User className="h-4 w-4 text-white" />
                      ) : message.isProcessing ? (
                        <Loader className="h-4 w-4 text-white animate-spin" />
                      ) : (
                        <Sparkles className="h-4 w-4 text-white" />
                      )}
                    </div>
                    <div className={`p-3 rounded-2xl ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : message.isProcessing
                        ? 'bg-yellow-50 text-yellow-800 border border-yellow-200'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString('pt-PT', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-gray-200">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Digite sua mensagem..."
                  className="flex-1 border border-gray-300 rounded-xl px-4 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  disabled={isLoading}
                />
                <button
                  onClick={sendMessage}
                  disabled={isLoading || !inputText.trim()}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-2 rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};