import React, { useState, useEffect } from 'react';
import { PiggyBank, Plus, TrendingUp, Calendar, Building, Percent, Target, Edit3, Trash2, DollarSign, Calculator, Sparkles, MessageCircle, Smartphone } from 'lucide-react';
import { SavingsBox, SavingsProjection } from '../types/savings';
import { useSavings } from '../hooks/useSavings';
import { useApp } from '../contexts/AppContext';

// Bancos com informações de CDI
const banksWithCDI = [
  { 
    id: 'nubank', 
    name: 'Nubank', 
    cdiPercentage: 100, 
    color: 'from-purple-600 to-purple-700',
    logo: '🟣',
    description: '100% do CDI'
  },
  { 
    id: 'inter', 
    name: 'Banco Inter', 
    cdiPercentage: 100, 
    color: 'from-orange-500 to-orange-600',
    logo: '🟠',
    description: '100% do CDI'
  },
  { 
    id: 'c6', 
    name: 'C6 Bank', 
    cdiPercentage: 95, 
    color: 'from-gray-700 to-gray-800',
    logo: '⚫',
    description: '95% do CDI'
  },
  { 
    id: 'picpay', 
    name: 'PicPay', 
    cdiPercentage: 102, 
    color: 'from-green-400 to-green-500',
    logo: '💚',
    description: '102% do CDI'
  },
  { 
    id: 'itau', 
    name: 'Itaú', 
    cdiPercentage: 90, 
    color: 'from-orange-500 to-orange-600',
    logo: '🟠',
    description: '90% do CDI'
  },
  { 
    id: 'bradesco', 
    name: 'Bradesco', 
    cdiPercentage: 85, 
    color: 'from-red-500 to-red-600',
    logo: '🔴',
    description: '85% do CDI'
  }
];

export const SavingsManager: React.FC = () => {
  const { formatCurrency } = useApp();
  const { 
    savingsBoxes, 
    addSavingsBox, 
    updateSavingsBox, 
    depositToSavingsBox, 
    deleteSavingsBox,
    fetchCurrentCDI,
    calculateProjection,
    loading 
  } = useSavings();

  const [showAddForm, setShowAddForm] = useState(false);
  const [editingBox, setEditingBox] = useState<string | null>(null);
  const [currentCDI, setCurrentCDI] = useState(8.25);
  const [projections, setProjections] = useState<{ [key: string]: SavingsProjection }>({});
  const [showProjection, setShowProjection] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    target_amount: '',
    current_amount: '',
    monthly_contribution: '',
    target_date: '',
    bank_name: '',
    cdi_percentage: '100',
    risk_level: 'low' as SavingsBox['risk_level'],
    auto_invest: false
  });

  // Carregar CDI atual
  useEffect(() => {
    fetchCurrentCDI().then(setCurrentCDI);
  }, [fetchCurrentCDI]);

  // Calcular projeções para todas as caixinhas
  useEffect(() => {
    const newProjections: { [key: string]: SavingsProjection } = {};
    
    savingsBoxes.forEach(box => {
      if (box.target_date && box.monthly_contribution > 0) {
        const targetDate = new Date(box.target_date);
        const today = new Date();
        const monthsToTarget = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 30));
        
        if (monthsToTarget > 0) {
          newProjections[box.id] = calculateProjection(
            box.current_amount,
            box.monthly_contribution,
            box.cdi_percentage,
            monthsToTarget,
            currentCDI
          );
        }
      }
    });
    
    setProjections(newProjections);
  }, [savingsBoxes, currentCDI, calculateProjection]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.name && formData.target_amount && formData.bank_name) {
      const selectedBank = banksWithCDI.find(bank => bank.id === formData.bank_name);
      
      const savingsData = {
        name: formData.name,
        description: formData.description,
        target_amount: Number(formData.target_amount) || 0,
        current_amount: Number(formData.current_amount || '0') || 0,
        monthly_contribution: Number(formData.monthly_contribution || '0') || 0,
        target_date: formData.target_date || undefined,
        bank_name: formData.bank_name,
        cdi_percentage: selectedBank?.cdiPercentage || Number(formData.cdi_percentage) || 100,
        risk_level: formData.risk_level,
        auto_invest: formData.auto_invest,
        is_active: true
      };

      if (editingBox) {
        await updateSavingsBox(editingBox, savingsData);
        setEditingBox(null);
      } else {
        await addSavingsBox(savingsData);
      }
      
      setFormData({
        name: '',
        description: '',
        target_amount: '',
        current_amount: '',
        monthly_contribution: '',
        target_date: '',
        bank_name: '',
        cdi_percentage: '100',
        risk_level: 'low',
        auto_invest: false
      });
      setShowAddForm(false);
    }
  };

  const handleEdit = (box: SavingsBox) => {
    setFormData({
      name: box.name,
      description: box.description || '',
      target_amount: box.target_amount.toString(),
      current_amount: box.current_amount.toString(),
      monthly_contribution: box.monthly_contribution.toString(),
      target_date: box.target_date || '',
      bank_name: box.bank_name,
      cdi_percentage: box.cdi_percentage.toString(),
      risk_level: box.risk_level,
      auto_invest: box.auto_invest
    });
    setEditingBox(box.id);
    setShowAddForm(true);
  };

  const handleDeposit = async (boxId: string, amount: number) => {
    await depositToSavingsBox(boxId, amount, `Depósito manual de ${formatCurrency(amount)}`);
  };

  const getBankInfo = (bankId: string) => {
    return banksWithCDI.find(bank => bank.id === bankId) || banksWithCDI[0];
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const getProjectedReturn = (box: SavingsBox) => {
    const projection = projections[box.id];
    if (!projection) return null;
    
    return {
      finalAmount: projection.finalAmount,
      totalInterest: projection.totalInterest,
      months: projection.months
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-2xl">
              <PiggyBank className="h-8 w-8 text-white" />
            </div>
            Minhas Caixinhas
          </h2>
          <div className="mt-2 flex items-center gap-4">
            <p className="text-gray-600">
              {savingsBoxes.length} caixinha{savingsBoxes.length !== 1 ? 's' : ''} ativa{savingsBoxes.length !== 1 ? 's' : ''}
            </p>
            <div className="flex items-center gap-2 bg-gradient-to-r from-green-50 to-emerald-50 px-4 py-2 rounded-xl border border-green-200">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <span className="font-bold text-green-700">
                CDI Atual: {currentCDI.toFixed(2)}% a.a.
              </span>
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
        >
          <Plus className="h-5 w-5" />
          Nova Caixinha
        </button>
      </div>

      {/* Resumo Geral */}
      {savingsBoxes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-2xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <PiggyBank className="h-8 w-8 text-green-200" />
              <TrendingUp className="h-6 w-6 text-green-200" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Total Poupado</h3>
            <p className="text-3xl font-bold">
              {formatCurrency(savingsBoxes.reduce((sum, box) => sum + box.current_amount, 0))}
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-2xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <Target className="h-8 w-8 text-blue-200" />
              <Calendar className="h-6 w-6 text-blue-200" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Meta Total</h3>
            <p className="text-3xl font-bold">
              {formatCurrency(savingsBoxes.reduce((sum, box) => sum + box.target_amount, 0))}
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-2xl shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <Calculator className="h-8 w-8 text-purple-200" />
              <Percent className="h-6 w-6 text-purple-200" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Rendimento Projetado</h3>
            <p className="text-3xl font-bold">
              {formatCurrency(
                Object.values(projections).reduce((sum, proj) => sum + proj.totalInterest, 0)
              )}
            </p>
          </div>
        </div>
      )}

      {/* Formulário de Nova Caixinha */}
      {showAddForm && (
        <div className="bg-gradient-to-br from-white to-green-50 rounded-3xl shadow-2xl p-8 animate-scaleIn border-2 border-green-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-4 rounded-2xl shadow-lg">
              <Plus className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-900">
                {editingBox ? 'Editar Caixinha' : 'Nova Caixinha'}
              </h3>
              <p className="text-gray-600 text-lg">
                {editingBox ? 'Modifique os dados da sua caixinha' : 'Crie uma nova caixinha de poupança'}
              </p>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Nome da Caixinha *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border-2 border-green-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-medium hover:shadow-xl"
                  placeholder="Ex: Viagem para Europa"
                  required
                />
              </div>
              
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Meta de Valor *
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-green-100 p-2 rounded-lg">
                    <span className="text-green-600 font-bold">R$</span>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.target_amount}
                    onChange={(e) => setFormData({ ...formData, target_amount: e.target.value })}
                    className="w-full pl-16 pr-6 py-4 border-2 border-green-200 rounded-2xl focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-semibold hover:shadow-xl"
                    placeholder="0,00"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Valor Inicial
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-green-100 p-2 rounded-lg">
                    <span className="text-green-600 font-bold">R$</span>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.current_amount}
                    onChange={(e) => setFormData({ ...formData, current_amount: e.target.value })}
                    className="w-full pl-16 pr-6 py-4 border-2 border-green-200 rounded-2xl focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-semibold hover:shadow-xl"
                    placeholder="0,00"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Contribuição Mensal
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-green-100 p-2 rounded-lg">
                    <span className="text-green-600 font-bold">R$</span>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.monthly_contribution}
                    onChange={(e) => setFormData({ ...formData, monthly_contribution: e.target.value })}
                    className="w-full pl-16 pr-6 py-4 border-2 border-green-200 rounded-2xl focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-semibold hover:shadow-xl"
                    placeholder="0,00"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Banco/Instituição *
                </label>
                <select
                  value={formData.bank_name}
                  onChange={(e) => {
                    const selectedBank = banksWithCDI.find(bank => bank.id === e.target.value);
                    setFormData({ 
                      ...formData, 
                      bank_name: e.target.value,
                      cdi_percentage: selectedBank?.cdiPercentage.toString() || '100'
                    });
                  }}
                  className="w-full border-2 border-green-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-medium hover:shadow-xl"
                  required
                >
                  <option value="">Selecione o banco</option>
                  {banksWithCDI.map((bank) => (
                    <option key={bank.id} value={bank.id}>
                      {bank.logo} {bank.name} - {bank.description}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-base font-bold text-gray-800 mb-3">
                  Data Meta
                </label>
                <input
                  type="date"
                  value={formData.target_date}
                  onChange={(e) => setFormData({ ...formData, target_date: e.target.value })}
                  className="w-full border-2 border-green-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-medium hover:shadow-xl"
                />
              </div>
            </div>

            <div>
              <label className="block text-base font-bold text-gray-800 mb-3">
                Descrição
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full border-2 border-green-200 rounded-2xl px-6 py-4 focus:ring-4 focus:ring-green-300 focus:border-green-500 transition-all duration-300 bg-white shadow-lg text-lg font-medium hover:shadow-xl resize-none"
                placeholder="Descreva o objetivo desta caixinha..."
              />
            </div>

            {/* Projeção em Tempo Real */}
            {formData.target_amount && formData.monthly_contribution && formData.target_date && formData.bank_name && (
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border-2 border-blue-200">
                <div className="flex items-center gap-3 mb-4">
                  <Calculator className="h-6 w-6 text-blue-600" />
                  <h4 className="text-lg font-bold text-blue-900">Projeção de Rendimento</h4>
                </div>
                
                {(() => {
                  const targetAmount = parseFloat(formData.target_amount);
                  const currentAmount = parseFloat(formData.current_amount || '0');
                  const monthlyContribution = parseFloat(formData.monthly_contribution);
                  const targetDate = new Date(formData.target_date);
                  const today = new Date();
                  const monthsToTarget = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 30));
                  const selectedBank = banksWithCDI.find(bank => bank.id === formData.bank_name);
                  
                  if (monthsToTarget > 0 && selectedBank) {
                    const projection = calculateProjection(
                      currentAmount,
                      monthlyContribution,
                      selectedBank.cdiPercentage,
                      monthsToTarget,
                      currentCDI
                    );

                    return (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded-xl border border-blue-200">
                          <h5 className="font-semibold text-blue-900 mb-2">Valor Final</h5>
                          <p className="text-2xl font-bold text-blue-700">
                            {formatCurrency(projection.finalAmount)}
                          </p>
                        </div>
                        <div className="bg-white p-4 rounded-xl border border-blue-200">
                          <h5 className="font-semibold text-blue-900 mb-2">Rendimento Total</h5>
                          <p className="text-2xl font-bold text-green-600">
                            +{formatCurrency(projection.totalInterest)}
                          </p>
                        </div>
                        <div className="bg-white p-4 rounded-xl border border-blue-200">
                          <h5 className="font-semibold text-blue-900 mb-2">Período</h5>
                          <p className="text-2xl font-bold text-purple-600">
                            {projection.months} meses
                          </p>
                        </div>
                      </div>
                    );
                  }
                  
                  return (
                    <p className="text-blue-700">Configure todos os campos para ver a projeção</p>
                  );
                })()}
              </div>
            )}

            <div className="flex gap-6 pt-4">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-2xl hover:shadow-3xl transform hover:-translate-y-2 hover:scale-105 transition-all duration-300"
              >
                {editingBox ? 'Salvar Alterações' : 'Criar Caixinha'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowAddForm(false);
                  setEditingBox(null);
                  setFormData({
                    name: '',
                    description: '',
                    target_amount: '',
                    current_amount: '',
                    monthly_contribution: '',
                    target_date: '',
                    bank_name: '',
                    cdi_percentage: '100',
                    risk_level: 'low',
                    auto_invest: false
                  });
                }}
                className="px-8 py-4 bg-gradient-to-r from-gray-200 to-gray-300 hover:from-gray-300 hover:to-gray-400 text-gray-700 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300"
              >
                Cancelar
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Lista de Caixinhas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {savingsBoxes.map((box) => {
          const bankInfo = getBankInfo(box.bank_name);
          const progress = getProgressPercentage(box.current_amount, box.target_amount);
          const projectedReturn = getProjectedReturn(box);
          const isCompleted = progress >= 100;

          return (
            <div 
              key={box.id} 
              className={`bg-gradient-to-br ${bankInfo.color} text-white p-6 rounded-2xl shadow-lg card-hover animate-slideIn relative overflow-hidden`}
            >
              {/* Logo do banco */}
              <div className="absolute top-4 right-4 text-2xl opacity-80">
                {bankInfo.logo}
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <PiggyBank className="h-6 w-6" />
                  <span className="text-sm opacity-90 font-medium">
                    {bankInfo.description}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowProjection(showProjection === box.id ? null : box.id)}
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 p-2 rounded-lg transition-all duration-200 transform hover:scale-110"
                    title="Ver projeção"
                  >
                    <Calculator className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleEdit(box)}
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 p-2 rounded-lg transition-all duration-200 transform hover:scale-110"
                    title="Editar caixinha"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => deleteSavingsBox(box.id)}
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 p-2 rounded-lg transition-all duration-200 transform hover:scale-110"
                    title="Excluir caixinha"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              
              <div className="mb-4">
                <h3 className="text-lg font-bold mb-1">{box.name}</h3>
                <p className="text-sm opacity-90">{bankInfo.name}</p>
                {box.description && (
                  <p className="text-sm opacity-80 mt-1">{box.description}</p>
                )}
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="opacity-90">Progresso</span>
                  <span className="font-bold">{progress.toFixed(1)}%</span>
                </div>
                
                <div className="w-full bg-white bg-opacity-30 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full transition-all duration-300 ${
                      isCompleted ? 'bg-yellow-400' : 'bg-white'
                    }`}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  ></div>
                </div>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="opacity-90">Atual / Meta</span>
                  <span className="font-bold">
                    {formatCurrency(box.current_amount)} / {formatCurrency(box.target_amount)}
                  </span>
                </div>

                {box.monthly_contribution > 0 && (
                  <div className="flex justify-between items-center text-sm">
                    <span className="opacity-90">Mensal</span>
                    <span className="font-bold">
                      {formatCurrency(box.monthly_contribution)}
                    </span>
                  </div>
                )}

                {projectedReturn && (
                  <div className="pt-3 border-t border-white border-opacity-20">
                    <div className="text-xs opacity-80 mb-2">Projeção CDI ({box.cdi_percentage}%)</div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="opacity-90">Rendimento</span>
                      <span className="font-bold text-yellow-200">
                        +{formatCurrency(projectedReturn.totalInterest)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="opacity-90">Valor Final</span>
                      <span className="font-bold text-yellow-200">
                        {formatCurrency(projectedReturn.finalAmount)}
                      </span>
                    </div>
                  </div>
                )}

                {box.target_date && (
                  <div className="text-center text-xs opacity-80">
                    Meta: {new Date(box.target_date).toLocaleDateString('pt-PT')}
                  </div>
                )}

                {isCompleted && (
                  <div className="text-center">
                    <span className="text-xs px-3 py-1 rounded-full bg-yellow-400 text-yellow-900 font-bold">
                      🎉 Meta Alcançada!
                    </span>
                  </div>
                )}
              </div>

              {/* Projeção Expandida */}
              {showProjection === box.id && projectedReturn && (
                <div className="mt-4 pt-4 border-t border-white border-opacity-20">
                  <h4 className="font-bold mb-3 flex items-center gap-2">
                    <Sparkles className="h-4 w-4" />
                    Projeção Detalhada
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                      <div className="flex justify-between">
                        <span>CDI Atual:</span>
                        <span className="font-bold">{currentCDI.toFixed(2)}% a.a.</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Seu Rendimento:</span>
                        <span className="font-bold">{(currentCDI * box.cdi_percentage / 100).toFixed(2)}% a.a.</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Período:</span>
                        <span className="font-bold">{projectedReturn.months} meses</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Estado vazio */}
      {savingsBoxes.length === 0 && !showAddForm && (
        <div className="text-center py-16 bg-white rounded-2xl shadow-lg">
          <div className="text-6xl mb-4">🐷</div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Nenhuma caixinha criada</h3>
          <p className="text-gray-600 mb-6 max-w-md mx-auto">
            Comece criando sua primeira caixinha de poupança e veja seus investimentos renderem com o CDI
          </p>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
          >
            Criar Primeira Caixinha
          </button>
        </div>
      )}

      {/* Dica sobre WhatsApp */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6">
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-full">
            <MessageCircle className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-green-900 mb-2">💡 Dica: Use o WhatsApp!</h3>
            <p className="text-green-800 mb-3">
              Conecte seu WhatsApp e gerencie suas caixinhas por mensagem:
            </p>
            <div className="space-y-1 text-sm text-green-700">
              <p>• <strong>"criar caixinha viagem 5000"</strong> - Cria nova caixinha</p>
              <p>• <strong>"depositar 200 na caixinha viagem"</strong> - Faz depósito</p>
              <p>• <strong>"saldo das caixinhas"</strong> - Consulta saldos</p>
            </div>
          </div>
          <div className="flex-shrink-0">
            <Smartphone className="h-12 w-12 text-green-600" />
          </div>
        </div>
      </div>
    </div>
  );
};