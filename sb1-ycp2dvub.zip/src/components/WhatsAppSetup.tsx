import React, { useState } from 'react';
import { MessageCircle, Smartphone, Shield, CheckCircle, AlertTriangle, Send, Phone, QrCode, Zap, Copy, ExternalLink, Settings, Key, Globe } from 'lucide-react';
import { useWhatsApp } from '../hooks/useWhatsApp';
import { useApp } from '../contexts/AppContext';

export const WhatsAppSetup: React.FC = () => {
  const { formatCurrency } = useApp();
  const { 
    whatsappUser, 
    messages, 
    loading, 
    connectWhatsApp, 
    verifyWhatsApp, 
    disconnectWhatsApp,
    sendTestMessage 
  } = useWhatsApp();

  const [showConnectForm, setShowConnectForm] = useState(false);
  const [showVerificationForm, setShowVerificationForm] = useState(false);
  const [showSetupGuide, setShowSetupGuide] = useState(false);
  const [testMessage, setTestMessage] = useState('');
  const [formData, setFormData] = useState({
    phoneNumber: '',
    whatsappNumber: ''
  });
  const [verificationCode, setVerificationCode] = useState('');

  // URLs e configurações para o setup
  const webhookUrl = `${window.location.origin}/functions/v1/whatsapp-processor`;
  const verifyToken = 'CRIE_UMA_SENHA_SECRETA_FORTE'; // Este deve ser o mesmo configurado no Supabase

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { data, error } = await connectWhatsApp(formData.phoneNumber, formData.whatsappNumber);
    
    if (error) {
      alert(`Erro: ${error.message}`);
    } else if (data) {
      setShowConnectForm(false);
      setShowVerificationForm(true);
      // Em produção, o código seria enviado via WhatsApp
      alert(`Código de verificação (TESTE): ${data.verification_code}`);
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { data, error } = await verifyWhatsApp(verificationCode);
    
    if (error) {
      alert(`Erro: ${error.message}`);
    } else {
      setShowVerificationForm(false);
      setVerificationCode('');
      alert('WhatsApp conectado com sucesso!');
    }
  };

  const handleTestMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { data, error } = await sendTestMessage(testMessage);
    
    if (error) {
      alert(`Erro: ${error.message}`);
    } else {
      setTestMessage('');
      alert('Mensagem processada com sucesso!');
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copiado para a área de transferência!');
  };

  const formatPhoneNumber = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 11) {
      return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
    }
    return phone;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-2xl">
              <MessageCircle className="h-8 w-8 text-white" />
            </div>
            Automação WhatsApp
          </h2>
          <p className="text-gray-600 mt-2">Sistema completo de lançamentos automáticos via WhatsApp com IA</p>
        </div>
        <button
          onClick={() => setShowSetupGuide(true)}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl flex items-center gap-2 font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
        >
          <Settings className="h-5 w-5" />
          Guia de Configuração
        </button>
      </div>

      {/* Status da Conexão */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className={`p-4 rounded-full ${
            whatsappUser?.is_verified 
              ? 'bg-gradient-to-r from-green-500 to-emerald-500' 
              : 'bg-gradient-to-r from-gray-400 to-gray-500'
          }`}>
            <Smartphone className="h-8 w-8 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              Status da Automação
            </h3>
            <p className={`text-lg font-semibold ${
              whatsappUser?.is_verified ? 'text-green-600' : 'text-gray-600'
            }`}>
              {whatsappUser?.is_verified ? '✅ Sistema Ativo e Funcionando' : '❌ Sistema Inativo'}
            </p>
          </div>
        </div>

        {whatsappUser?.is_verified ? (
          <div className="space-y-6">
            {/* Informações da Conexão */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <h4 className="text-lg font-bold text-green-900">WhatsApp Conectado e Verificado</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <span className="text-green-700 font-semibold">📱 Seu Número:</span>
                  <p className="text-green-800 text-lg font-bold">{formatPhoneNumber(whatsappUser.phone_number)}</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-green-200">
                  <span className="text-green-700 font-semibold">💬 WhatsApp:</span>
                  <p className="text-green-800 text-lg font-bold">{formatPhoneNumber(whatsappUser.whatsapp_number)}</p>
                </div>
              </div>
            </div>

            {/* Teste do Sistema */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <Send className="h-6 w-6 text-blue-600" />
                <h4 className="text-lg font-bold text-blue-900">Testar Sistema</h4>
              </div>
              
              <form onSubmit={handleTestMessage} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-blue-700 mb-2">
                    Mensagem de Teste
                  </label>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={testMessage}
                      onChange={(e) => setTestMessage(e.target.value)}
                      className="flex-1 border-2 border-blue-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                      placeholder="Ex: gastei 50 no supermercado"
                      required
                    />
                    <button
                      type="submit"
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                    >
                      <Send className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </form>

              <div className="mt-4 bg-white p-4 rounded-lg border border-blue-200">
                <h5 className="font-semibold text-blue-900 mb-2">💡 Comandos de Teste:</h5>
                <div className="space-y-1 text-sm text-blue-800">
                  <button 
                    onClick={() => setTestMessage('gastei 25 na padaria')}
                    className="block w-full text-left hover:bg-blue-50 p-2 rounded"
                  >
                    • "gastei 25 na padaria"
                  </button>
                  <button 
                    onClick={() => setTestMessage('recebi 1200 de salário')}
                    className="block w-full text-left hover:bg-blue-50 p-2 rounded"
                  >
                    • "recebi 1200 de salário"
                  </button>
                  <button 
                    onClick={() => setTestMessage('criar caixinha viagem 5000')}
                    className="block w-full text-left hover:bg-blue-50 p-2 rounded"
                  >
                    • "criar caixinha viagem 5000"
                  </button>
                  <button 
                    onClick={() => setTestMessage('depositar 200 na caixinha viagem')}
                    className="block w-full text-left hover:bg-blue-50 p-2 rounded"
                  >
                    • "depositar 200 na caixinha viagem"
                  </button>
                  <button 
                    onClick={() => setTestMessage('saldo das caixinhas')}
                    className="block w-full text-left hover:bg-blue-50 p-2 rounded"
                  >
                    • "saldo das caixinhas"
                  </button>
                </div>
              </div>
            </div>

            {/* Ações de Gerenciamento */}
            <div className="flex gap-4">
              <button
                onClick={() => setShowConnectForm(true)}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Alterar Número
              </button>
              <button
                onClick={disconnectWhatsApp}
                className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Desconectar
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-6xl mb-4">📱</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Configure a Automação WhatsApp</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Conecte seu WhatsApp para gerenciar suas finanças por mensagem. 
              Envie comandos como "gastei 50 no supermercado" e receba confirmações automáticas!
            </p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => setShowConnectForm(true)}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Conectar WhatsApp
              </button>
              <button
                onClick={() => setShowSetupGuide(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Ver Guia Completo
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Formulário de Conexão */}
      {showConnectForm && (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6 rounded-t-3xl">
              <div className="flex items-center gap-3">
                <div className="bg-white bg-opacity-20 p-3 rounded-full">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Conectar WhatsApp</h3>
                  <p className="text-white text-opacity-90">Configure sua integração</p>
                </div>
              </div>
            </div>
            
            <form onSubmit={handleConnect} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Seu Telefone
                </label>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                  placeholder="(11) 99999-9999"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Número do WhatsApp
                </label>
                <input
                  type="tel"
                  value={formData.whatsappNumber}
                  onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all duration-200"
                  placeholder="5511999999999"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Formato: código do país + DDD + número (ex: 5511999999999)
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-3 px-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  Conectar
                </button>
                <button
                  type="button"
                  onClick={() => setShowConnectForm(false)}
                  className="px-6 py-3 bg-gradient-to-r from-gray-200 to-gray-300 hover:from-gray-300 hover:to-gray-400 text-gray-700 rounded-xl font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Formulário de Verificação */}
      {showVerificationForm && (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 rounded-t-3xl">
              <div className="flex items-center gap-3">
                <div className="bg-white bg-opacity-20 p-3 rounded-full">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Verificar WhatsApp</h3>
                  <p className="text-white text-opacity-90">Digite o código recebido</p>
                </div>
              </div>
            </div>
            
            <form onSubmit={handleVerify} className="p-6 space-y-4">
              <div className="text-center mb-4">
                <div className="text-4xl mb-2">📱</div>
                <p className="text-gray-600">
                  Enviamos um código de verificação para seu WhatsApp
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Código de Verificação
                </label>
                <input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 text-center text-2xl font-bold tracking-widest"
                  placeholder="123456"
                  maxLength={6}
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 px-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  Verificar
                </button>
                <button
                  type="button"
                  onClick={() => setShowVerificationForm(false)}
                  className="px-6 py-3 bg-gradient-to-r from-gray-200 to-gray-300 hover:from-gray-300 hover:to-gray-400 text-gray-700 rounded-xl font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Guia de Configuração Completo */}
      {showSetupGuide && (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 rounded-t-3xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-white bg-opacity-20 p-3 rounded-full">
                    <Settings className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">Guia de Configuração Completo</h3>
                    <p className="text-white text-opacity-90">Sistema de Automação WhatsApp com IA</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSetupGuide(false)}
                  className="text-white hover:bg-white hover:bg-opacity-20 p-2 rounded-full transition-all duration-200"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-8 space-y-8">
              {/* Passo 1: Configurar Supabase */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl border border-blue-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">1</div>
                  <h4 className="text-xl font-bold text-blue-900">Configurar Supabase Edge Function</h4>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h5 className="font-semibold text-blue-800 mb-2">🔧 Comandos para executar:</h5>
                    <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm space-y-2">
                      <div className="flex items-center justify-between">
                        <span># 1. Instalar Supabase CLI</span>
                        <button onClick={() => copyToClipboard('npm install supabase --save-dev')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npm install supabase --save-dev</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <span># 2. Fazer login no Supabase</span>
                        <button onClick={() => copyToClipboard('npx supabase login')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase login</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <span># 3. Linkar projeto</span>
                        <button onClick={() => copyToClipboard('npx supabase link --project-ref SEU_PROJECT_ID')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase link --project-ref SEU_PROJECT_ID</p>
                    </div>
                  </div>

                  <div>
                    <h5 className="font-semibold text-blue-800 mb-2">🔑 Configurar Variáveis de Ambiente:</h5>
                    <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm space-y-2">
                      <div className="flex items-center justify-between">
                        <span># OpenAI API Key</span>
                        <button onClick={() => copyToClipboard('npx supabase secrets set OPENAI_API_KEY="sk-..."')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase secrets set OPENAI_API_KEY="sk-..."</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <span># Meta WhatsApp Token</span>
                        <button onClick={() => copyToClipboard('npx supabase secrets set META_WHATSAPP_TOKEN="SEU_TOKEN"')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase secrets set META_WHATSAPP_TOKEN="SEU_TOKEN"</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <span># Meta Phone Number ID</span>
                        <button onClick={() => copyToClipboard('npx supabase secrets set META_PHONE_NUMBER_ID="SEU_ID"')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase secrets set META_PHONE_NUMBER_ID="SEU_ID"</p>
                      
                      <div className="flex items-center justify-between mt-4">
                        <span># Token de Verificação</span>
                        <button onClick={() => copyToClipboard(`npx supabase secrets set META_VERIFY_TOKEN="${verifyToken}"`)} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase secrets set META_VERIFY_TOKEN="{verifyToken}"</p>
                    </div>
                  </div>

                  <div>
                    <h5 className="font-semibold text-blue-800 mb-2">🚀 Deploy da Função:</h5>
                    <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm">
                      <div className="flex items-center justify-between">
                        <span># Deploy da Edge Function</span>
                        <button onClick={() => copyToClipboard('npx supabase functions deploy whatsapp-processor --no-verify-jwt')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                      <p>npx supabase functions deploy whatsapp-processor --no-verify-jwt</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Passo 2: Configurar Meta for Developers */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-green-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">2</div>
                  <h4 className="text-xl font-bold text-green-900">Configurar Meta for Developers</h4>
                </div>

                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-xl border border-green-200">
                    <h5 className="font-semibold text-green-800 mb-2">🌐 URL do Webhook:</h5>
                    <div className="flex items-center gap-2 bg-gray-100 p-3 rounded-lg">
                      <code className="flex-1 text-sm text-gray-800 break-all">{webhookUrl}</code>
                      <button 
                        onClick={() => copyToClipboard(webhookUrl)}
                        className="text-green-600 hover:text-green-800 p-1"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-green-200">
                    <h5 className="font-semibold text-green-800 mb-2">🔐 Token de Verificação:</h5>
                    <div className="flex items-center gap-2 bg-gray-100 p-3 rounded-lg">
                      <code className="flex-1 text-sm text-gray-800">{verifyToken}</code>
                      <button 
                        onClick={() => copyToClipboard(verifyToken)}
                        className="text-green-600 hover:text-green-800 p-1"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-green-200">
                    <h5 className="font-semibold text-green-800 mb-3">📋 Passos no Meta for Developers:</h5>
                    <ol className="list-decimal list-inside space-y-2 text-sm text-green-700">
                      <li>Acesse <a href="https://developers.facebook.com" target="_blank" className="text-blue-600 hover:underline">Meta for Developers</a></li>
                      <li>Vá para sua aplicação WhatsApp Business</li>
                      <li>Na seção "WhatsApp" → "Configuração da API"</li>
                      <li>Encontre a área de "Webhooks"</li>
                      <li>Cole a URL do webhook acima</li>
                      <li>Cole o token de verificação acima</li>
                      <li>Clique em "Verificar e salvar"</li>
                      <li>Subscreva o evento "messages"</li>
                    </ol>
                  </div>
                </div>
              </div>

              {/* Passo 3: Testar Sistema */}
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl border border-purple-200">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-purple-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold">3</div>
                  <h4 className="text-xl font-bold text-purple-900">Testar e Monitorar</h4>
                </div>

                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-xl border border-purple-200">
                    <h5 className="font-semibold text-purple-800 mb-2">🔍 Monitorar Logs:</h5>
                    <div className="bg-gray-900 text-green-400 p-3 rounded-lg font-mono text-sm">
                      <div className="flex items-center justify-between">
                        <span>npx supabase functions logs whatsapp-processor</span>
                        <button onClick={() => copyToClipboard('npx supabase functions logs whatsapp-processor')} className="text-blue-400 hover:text-blue-300">
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-purple-600 mt-2">
                      Execute este comando para ver logs em tempo real durante os testes
                    </p>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-purple-200">
                    <h5 className="font-semibold text-purple-800 mb-2">📱 Comandos de Teste:</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                      <div className="bg-purple-100 p-2 rounded">
                        <strong>Transações:</strong>
                        <ul className="mt-1 space-y-1 text-purple-700">
                          <li>• "gastei 50 no supermercado"</li>
                          <li>• "recebi 1200 de salário"</li>
                          <li>• "paguei 80 na farmácia"</li>
                        </ul>
                      </div>
                      <div className="bg-purple-100 p-2 rounded">
                        <strong>Caixinhas:</strong>
                        <ul className="mt-1 space-y-1 text-purple-700">
                          <li>• "criar caixinha viagem 5000"</li>
                          <li>• "depositar 200 na caixinha viagem"</li>
                          <li>• "saldo das caixinhas"</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Informações Técnicas */}
              <div className="bg-gradient-to-r from-gray-50 to-slate-50 p-6 rounded-2xl border border-gray-200">
                <div className="flex items-center gap-3 mb-4">
                  <Key className="h-6 w-6 text-gray-600" />
                  <h4 className="text-xl font-bold text-gray-900">Informações Técnicas</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-xl border border-gray-200">
                    <h5 className="font-semibold text-gray-800 mb-2">🔗 URLs Importantes:</h5>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="text-gray-600">Webhook URL:</span>
                        <p className="font-mono text-xs text-blue-600 break-all">{webhookUrl}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Meta Developers:</span>
                        <a href="https://developers.facebook.com" target="_blank" className="text-blue-600 hover:underline flex items-center gap-1">
                          developers.facebook.com <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-gray-200">
                    <h5 className="font-semibold text-gray-800 mb-2">🛠️ Solução de Problemas:</h5>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Verifique os logs em tempo real</li>
                      <li>• Confirme tokens idênticos</li>
                      <li>• Reimplante após mudanças</li>
                      <li>• Teste com mensagens simples</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => setShowSetupGuide(false)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  Entendi, Fechar Guia
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Teste do Sistema (quando conectado) */}
      {whatsappUser?.is_verified && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-3 rounded-full">
              <Send className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Testar Automação</h3>
              <p className="text-gray-600">Envie comandos para a Sofia processar</p>
            </div>
          </div>

          <form onSubmit={handleTestMessage} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Comando de Teste
              </label>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                  className="flex-1 border-2 border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                  placeholder="Ex: gastei 50 no supermercado"
                  required
                />
                <button
                  type="submit"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>
          </form>

          {/* Comandos Rápidos */}
          <div className="mt-6 bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-xl border border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-3">⚡ Comandos Rápidos:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {[
                'gastei 25 na padaria',
                'recebi 1200 de salário',
                'criar caixinha viagem 5000',
                'depositar 200 na caixinha viagem',
                'saldo das caixinhas',
                'gastei 80 na farmácia'
              ].map((command, index) => (
                <button
                  key={index}
                  onClick={() => setTestMessage(command)}
                  className="text-left bg-white hover:bg-blue-50 p-3 rounded-lg border border-blue-200 hover:border-blue-300 transition-all duration-200 text-sm text-blue-800"
                >
                  "{command}"
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Histórico de Mensagens */}
      {whatsappUser?.is_verified && messages.length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-full">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">Histórico de Automação</h3>
              <p className="text-gray-600">Últimas interações processadas pela Sofia</p>
            </div>
          </div>

          <div className="space-y-4 max-h-96 overflow-y-auto">
            {messages.slice(0, 10).map((message) => (
              <div key={message.id} className="border border-gray-200 rounded-xl p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      message.success ? 'bg-green-500' : 'bg-red-500'
                    }`}></div>
                    <span className="text-sm font-medium text-gray-600">
                      {new Date(message.created_at).toLocaleString('pt-PT')}
                    </span>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    message.success 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {message.action_taken || (message.success ? 'Processado' : 'Erro')}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-800">
                      <strong>📱 Você:</strong> {message.message_text}
                    </p>
                  </div>
                  
                  {message.ai_response && (
                    <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                      <p className="text-sm text-green-800 whitespace-pre-wrap">
                        <strong>🤖 Sofia:</strong> {message.ai_response}
                      </p>
                    </div>
                  )}
                  
                  {message.error_message && (
                    <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                      <p className="text-sm text-red-800">
                        <strong>❌ Erro:</strong> {message.error_message}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Como Funciona */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-full">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-green-900">Como Funciona a Automação</h3>
            <p className="text-green-700">Fluxo completo do sistema</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white p-4 rounded-xl border border-green-200 text-center">
            <div className="text-3xl mb-3">📱</div>
            <h4 className="font-bold text-green-900 mb-2">1. Enviar Mensagem</h4>
            <p className="text-green-800 text-sm">
              Você envia uma mensagem natural para o WhatsApp Business
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-green-200 text-center">
            <div className="text-3xl mb-3">🤖</div>
            <h4 className="font-bold text-green-900 mb-2">2. IA Processa</h4>
            <p className="text-green-800 text-sm">
              A Sofia (OpenAI) analisa e extrai dados estruturados
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-green-200 text-center">
            <div className="text-3xl mb-3">💾</div>
            <h4 className="font-bold text-green-900 mb-2">3. Salvar Dados</h4>
            <p className="text-green-800 text-sm">
              Os dados são salvos automaticamente no Supabase
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-green-200 text-center">
            <div className="text-3xl mb-3">✅</div>
            <h4 className="font-bold text-green-900 mb-2">4. Confirmação</h4>
            <p className="text-green-800 text-sm">
              Você recebe uma confirmação automática no WhatsApp
            </p>
          </div>
        </div>
      </div>

      {/* Benefícios */}
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-6 border border-yellow-200">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-3 rounded-full">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-yellow-900">Benefícios da Automação</h3>
            <p className="text-yellow-800">Por que usar este sistema</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-xl border border-yellow-200">
            <div className="text-2xl mb-3">⚡</div>
            <h4 className="font-bold text-yellow-900 mb-2">Velocidade</h4>
            <p className="text-yellow-800 text-sm">
              Registre transações em segundos, sem abrir apps ou preencher formulários
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-yellow-200">
            <div className="text-2xl mb-3">🎯</div>
            <h4 className="font-bold text-yellow-900 mb-2">Precisão</h4>
            <p className="text-yellow-800 text-sm">
              IA categoriza automaticamente suas transações com alta precisão
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-yellow-200">
            <div className="text-2xl mb-3">📊</div>
            <h4 className="font-bold text-yellow-900 mb-2">Tempo Real</h4>
            <p className="text-yellow-800 text-sm">
              Dados aparecem instantaneamente no seu dashboard financeiro
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};