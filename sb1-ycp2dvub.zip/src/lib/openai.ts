import OpenAI from 'openai';

const apiKey = import.meta.env.VITE_OPENAI_API_KEY || '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';

if (!apiKey) {
  console.warn('OpenAI API key not configured. Please set VITE_OPENAI_API_KEY in your .env file');
}

const openai = new OpenAI({
  apiKey: apiKey,
  dangerouslyAllowBrowser: true
});

export { openai };