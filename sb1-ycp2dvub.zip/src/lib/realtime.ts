import { supabase } from './supabase';
import { RealtimeChannel } from '@supabase/supabase-js';

export class RealtimeManager {
  private channels: Map<string, RealtimeChannel> = new Map();

  // Escutar mudanças em transações
  subscribeToTransactions(userId: string, callback: (payload: any) => void): () => void {
    const channelName = `transactions-${userId}`;
    
    // Remover canal existente se houver
    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName);
    }

    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('Nova transação recebida via realtime:', payload.new);
          callback(payload);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('Transação atualizada via realtime:', payload.new);
          callback(payload);
        }
      )
      .subscribe((status) => {
        console.log(`Status da subscrição de transações: ${status}`);
      });

    this.channels.set(channelName, channel);

    // Retornar função de cleanup
    return () => this.unsubscribe(channelName);
  }

  // Escutar mudanças em caixinhas
  subscribeToSavingsBoxes(userId: string, callback: (payload: any) => void): () => void {
    const channelName = `savings-${userId}`;
    
    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName);
    }

    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'savings_boxes',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('Mudança em caixinha via realtime:', payload);
          callback(payload);
        }
      )
      .subscribe((status) => {
        console.log(`Status da subscrição de caixinhas: ${status}`);
      });

    this.channels.set(channelName, channel);

    return () => this.unsubscribe(channelName);
  }

  // Escutar mensagens do WhatsApp
  subscribeToWhatsAppMessages(userId: string, callback: (payload: any) => void): () => void {
    const channelName = `whatsapp-${userId}`;
    
    if (this.channels.has(channelName)) {
      this.unsubscribe(channelName);
    }

    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'whatsapp_messages',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('Nova mensagem WhatsApp via realtime:', payload.new);
          callback(payload);
        }
      )
      .subscribe((status) => {
        console.log(`Status da subscrição de mensagens WhatsApp: ${status}`);
      });

    this.channels.set(channelName, channel);

    return () => this.unsubscribe(channelName);
  }

  // Cancelar subscrição específica
  unsubscribe(channelName: string): void {
    const channel = this.channels.get(channelName);
    if (channel) {
      supabase.removeChannel(channel);
      this.channels.delete(channelName);
      console.log(`Canal ${channelName} removido`);
    }
  }

  // Cancelar todas as subscrições
  unsubscribeAll(): void {
    this.channels.forEach((channel, name) => {
      supabase.removeChannel(channel);
      console.log(`Canal ${name} removido`);
    });
    this.channels.clear();
  }
}

// Instância singleton
export const realtimeManager = new RealtimeManager();