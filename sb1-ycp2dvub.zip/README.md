# 🚀 Sistema de Automação Financeira via WhatsApp

## 📋 Visão Geral

Este é um sistema completo de gestão financeira pessoal com automação via WhatsApp. Os usuários podem enviar mensagens como "gastei 50 reais no almoço" e o sistema automaticamente:

1. **Processa** a mensagem com IA (OpenAI)
2. **Categoriza** automaticamente a transação
3. **Salva** os dados no Supabase
4. **Confirma** via WhatsApp
5. **Atualiza** o dashboard em tempo real

## 🏗️ Arquitetura

```
WhatsApp Business (Meta) → Supabase Edge Function → OpenAI → Supabase DB → React Frontend
```

### Componentes Principais:

- **Frontend React**: Dashboard financeiro completo
- **Supabase Edge Function**: Processamento de webhooks do WhatsApp
- **OpenAI GPT-4**: Processamento de linguagem natural
- **Supabase Database**: Armazenamento de dados
- **Meta WhatsApp Business API**: Integração com WhatsApp

## 🛠️ Configuração

### 1. Configurar Supabase

```bash
# Instalar CLI
npm install supabase --save-dev

# Login
npx supabase login

# Linkar projeto
npx supabase link --project-ref SEU_PROJECT_ID

# Configurar variáveis de ambiente
npx supabase secrets set OPENAI_API_KEY="sk-..."
npx supabase secrets set META_WHATSAPP_TOKEN="SEU_TOKEN"
npx supabase secrets set META_PHONE_NUMBER_ID="SEU_ID"
npx supabase secrets set META_VERIFY_TOKEN="SENHA_SECRETA"

# Deploy da função
npx supabase functions deploy whatsapp-processor --no-verify-jwt
```

### 2. Configurar Meta for Developers

1. Acesse [Meta for Developers](https://developers.facebook.com)
2. Crie uma aplicação WhatsApp Business
3. Configure o webhook:
   - **URL**: `https://SEU_PROJECT.supabase.co/functions/v1/whatsapp-processor`
   - **Token de Verificação**: A mesma senha configurada em `META_VERIFY_TOKEN`
4. Subscreva o evento `messages`

### 3. Testar Sistema

```bash
# Monitorar logs em tempo real
npx supabase functions logs whatsapp-processor
```

## 📱 Comandos Disponíveis

### Transações
- `"gastei 50 no supermercado"` → Registra despesa
- `"recebi 1200 de salário"` → Registra receita
- `"paguei 80 na farmácia"` → Registra despesa categorizada

### Caixinhas de Poupança
- `"criar caixinha viagem 5000"` → Cria nova caixinha
- `"depositar 200 na caixinha viagem"` → Faz depósito
- `"saldo das caixinhas"` → Consulta saldos

### Consultas
- `"meu saldo"` → Consulta saldo total
- `"gastos do mês"` → Relatório mensal

## 🤖 IA Sofia

A Sofia é a assistente financeira que processa comandos em linguagem natural:

- **Categorização Automática**: Identifica automaticamente categorias baseadas no contexto
- **Processamento Inteligente**: Extrai valores, locais e tipos de transação
- **Respostas Contextuais**: Fornece confirmações detalhadas
- **Fallback Local**: Funciona mesmo sem OpenAI para comandos básicos

## 🔄 Tempo Real

O sistema utiliza Supabase Realtime para:

- **Atualizações Instantâneas**: Dashboard atualiza automaticamente
- **Notificações Push**: Alertas de novas transações
- **Sincronização**: Dados sempre atualizados entre dispositivos

## 🛡️ Segurança

- **Row Level Security (RLS)**: Cada usuário vê apenas seus dados
- **Verificação de Número**: WhatsApp deve ser verificado antes do uso
- **Tokens Seguros**: Todas as chaves são armazenadas como secrets
- **Validação de Webhook**: Verificação de origem das mensagens

## 📊 Funcionalidades

### Dashboard Financeiro
- Visão geral de saldos e transações
- Gráficos interativos (categorias, fluxo de caixa, evolução)
- Gestão de contas e cartões
- Metas financeiras
- Limites de gastos

### Caixinhas de Poupança
- Criação de metas de poupança
- Cálculo de rendimento CDI
- Projeções de crescimento
- Depósitos automáticos

### Integração WhatsApp
- Conexão e verificação de número
- Processamento de comandos
- Histórico de mensagens
- Teste de funcionalidades

## 🔧 Solução de Problemas

### Webhook não valida
1. Verifique os logs: `npx supabase functions logs whatsapp-processor`
2. Confirme que os tokens são idênticos
3. Reimplante a função após mudanças
4. Teste com mensagens simples primeiro

### IA não responde
1. Verifique se `OPENAI_API_KEY` está configurada
2. O sistema tem fallback local para comandos básicos
3. Monitore os logs para erros específicos

### Dados não aparecem
1. Verifique se o usuário está conectado e verificado
2. Confirme que as políticas RLS estão corretas
3. Teste primeiro com a interface web

## 🚀 Deploy

O sistema está configurado para deploy automático. Após configurar as variáveis de ambiente e fazer o deploy da Edge Function, o sistema estará pronto para uso.

## 📞 Suporte

Para suporte técnico, verifique:
1. Logs da Edge Function
2. Console do navegador
3. Painel do Supabase
4. Meta for Developers

---

**Desenvolvido com ❤️ usando React, Supabase, OpenAI e Meta WhatsApp Business API**