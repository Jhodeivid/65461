import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
};

interface TransactionData {
  type: 'income' | 'expense' | 'transfer' | 'savings';
  amount: number;
  title: string;
  description: string;
  category?: string;
  subcategory?: string;
  savings_box_name?: string;
  bank_name?: string;
  payment_method?: string;
  status?: string;
}

// Sistema de processamento de comandos da Sofia (versão melhorada)
async function processMessageWithSofia(message: string, userId: string): Promise<any> {
  const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!openaiApiKey) {
    console.log('OpenAI API key não configurada, usando processamento local');
    return processMessageLocally(message);
  }

  const systemPrompt = `
Você é a Sofia, uma assistente financeira inteligente que processa comandos em português e retorna SEMPRE em formato JSON válido.

REGRAS CRÍTICAS:
1. SEMPRE responda em JSON válido
2. Identifique automaticamente categorias baseadas no contexto
3. Para transações: use "CREATE_TRANSACTION"
4. Para caixinhas: use "CREATE_SAVINGS_BOX" ou "DEPOSIT_SAVINGS"
5. Para consultas: use "QUERY_SAVINGS" ou "QUERY_BALANCE"

CATEGORIAS DISPONÍVEIS:
- alimentacao: padaria, supermercado, restaurante, delivery, café
- transporte: uber, taxi, gasolina, combustível, estacionamento
- moradia: aluguel, condomínio, luz, água, gás, internet
- saude-bem-estar: farmácia, médico, dentista, academia
- compras-lazer: shopping, loja, cinema, roupas, eletrônicos
- outros: para casos não identificados

FORMATO DE RESPOSTA OBRIGATÓRIO:
{
  "action": "CREATE_TRANSACTION" | "CREATE_SAVINGS_BOX" | "DEPOSIT_SAVINGS" | "QUERY_SAVINGS" | "ERROR",
  "data": {
    // Dados específicos da ação
  },
  "message": "Mensagem de confirmação para o utilizador",
  "category": "categoria identificada (se aplicável)",
  "subcategory": "subcategoria identificada (se aplicável)",
  "confidence": 0.0-1.0
}

EXEMPLOS:

Para "gastei 25 na padaria":
{
  "action": "CREATE_TRANSACTION",
  "data": {
    "type": "expense",
    "amount": 25.00,
    "title": "Padaria",
    "description": "Compra na padaria",
    "category": "alimentacao",
    "subcategory": "padaria",
    "payment_method": "cash",
    "status": "paid"
  },
  "message": "✅ Despesa de R$ 25,00 na padaria registrada!",
  "category": "alimentacao",
  "subcategory": "padaria",
  "confidence": 0.95
}

Para "recebi 1200 de salário":
{
  "action": "CREATE_TRANSACTION",
  "data": {
    "type": "income",
    "amount": 1200.00,
    "title": "Salário",
    "description": "Recebimento de salário",
    "category": "renda",
    "subcategory": "salarios",
    "payment_method": "account",
    "status": "received"
  },
  "message": "✅ Receita de R$ 1.200,00 de salário registrada!",
  "confidence": 0.98
}

Para "criar caixinha viagem 5000":
{
  "action": "CREATE_SAVINGS_BOX",
  "data": {
    "name": "Viagem",
    "target_amount": 5000.00,
    "description": "Caixinha para viagem",
    "bank_name": "Nubank",
    "cdi_percentage": 100
  },
  "message": "✅ Caixinha 'Viagem' criada com meta de R$ 5.000,00!",
  "confidence": 0.90
}

Para "depositar 200 na caixinha viagem":
{
  "action": "DEPOSIT_SAVINGS",
  "data": {
    "savings_box_name": "viagem",
    "amount": 200.00,
    "description": "Depósito na caixinha viagem"
  },
  "message": "✅ Depósito de R$ 200,00 na caixinha viagem realizado!",
  "confidence": 0.92
}

IMPORTANTE: Sua resposta será processada automaticamente, então o JSON deve ser perfeito e válido.
`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openaiApiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Processar: "${message}"` }
        ],
        temperature: 0.3,
        max_tokens: 500,
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const sofiaResponse = JSON.parse(data.choices[0].message.content);
    
    console.log('Resposta da Sofia (OpenAI):', sofiaResponse);
    return sofiaResponse;

  } catch (error) {
    console.error('Erro na OpenAI, usando processamento local:', error);
    return processMessageLocally(message);
  }
}

// Processamento local quando OpenAI não está disponível
function processMessageLocally(message: string): any {
  const lowerMessage = message.toLowerCase();
  
  // Detectar criação de caixinha
  if (lowerMessage.includes('criar caixinha') || lowerMessage.includes('nova caixinha')) {
    const amountMatch = message.match(/(\d+(?:[.,]\d{2})?)/);
    const nameMatch = message.match(/caixinha\s+([a-zA-ZÀ-ÿ\s]+?)(?:\s+\d|$)/i);
    
    if (amountMatch && nameMatch) {
      return {
        action: 'CREATE_SAVINGS_BOX',
        data: {
          name: nameMatch[1].trim(),
          target_amount: parseFloat(amountMatch[1].replace(',', '.')),
          description: `Caixinha para ${nameMatch[1].trim()}`,
          bank_name: 'Nubank',
          cdi_percentage: 100
        },
        message: `✅ Caixinha '${nameMatch[1].trim()}' criada com meta de R$ ${parseFloat(amountMatch[1].replace(',', '.')).toFixed(2)}!`,
        confidence: 0.90
      };
    }
  }
  
  // Detectar depósito em caixinha
  if (lowerMessage.includes('depositar') && lowerMessage.includes('caixinha')) {
    const amountMatch = message.match(/(\d+(?:[.,]\d{2})?)/);
    const nameMatch = message.match(/caixinha\s+([a-zA-ZÀ-ÿ\s]+)/i);
    
    if (amountMatch && nameMatch) {
      return {
        action: 'DEPOSIT_SAVINGS',
        data: {
          savings_box_name: nameMatch[1].trim().toLowerCase(),
          amount: parseFloat(amountMatch[1].replace(',', '.')),
          description: `Depósito na caixinha ${nameMatch[1].trim()}`
        },
        message: `✅ Depósito de R$ ${parseFloat(amountMatch[1].replace(',', '.')).toFixed(2)} na caixinha ${nameMatch[1].trim()} realizado!`,
        confidence: 0.92
      };
    }
  }
  
  // Detectar consulta de saldo
  if (lowerMessage.includes('saldo') && (lowerMessage.includes('caixinha') || lowerMessage.includes('poupado'))) {
    return {
      action: 'QUERY_SAVINGS',
      data: {},
      message: 'Consultando saldo das suas caixinhas...',
      confidence: 0.85
    };
  }
  
  // Detectar transações
  if (lowerMessage.includes('gastei') || lowerMessage.includes('paguei')) {
    const amountMatch = message.match(/(\d+(?:[.,]\d{2})?)/);
    if (amountMatch) {
      let category = 'outros';
      let subcategory = '';
      let title = 'Despesa';
      
      if (lowerMessage.includes('supermercado') || lowerMessage.includes('mercado')) {
        category = 'alimentacao';
        subcategory = 'supermercado';
        title = 'Supermercado';
      } else if (lowerMessage.includes('padaria')) {
        category = 'alimentacao';
        subcategory = 'padaria';
        title = 'Padaria';
      } else if (lowerMessage.includes('restaurante') || lowerMessage.includes('almoço') || lowerMessage.includes('jantar')) {
        category = 'alimentacao';
        subcategory = 'restaurante-delivery';
        title = 'Restaurante';
      } else if (lowerMessage.includes('gasolina') || lowerMessage.includes('combustível')) {
        category = 'transporte';
        subcategory = 'manutencao-carro';
        title = 'Combustível';
      } else if (lowerMessage.includes('farmácia') || lowerMessage.includes('remédio')) {
        category = 'saude-bem-estar';
        subcategory = 'farmacia-medicamentos';
        title = 'Farmácia';
      }
      
      return {
        action: 'CREATE_TRANSACTION',
        data: {
          type: 'expense',
          amount: parseFloat(amountMatch[1].replace(',', '.')),
          title,
          description: message,
          category,
          subcategory,
          payment_method: 'cash',
          status: 'paid'
        },
        message: `✅ Despesa de R$ ${parseFloat(amountMatch[1].replace(',', '.')).toFixed(2)} registrada!`,
        confidence: 0.95
      };
    }
  }
  
  if (lowerMessage.includes('recebi') || lowerMessage.includes('salário')) {
    const amountMatch = message.match(/(\d+(?:[.,]\d{2})?)/);
    if (amountMatch) {
      return {
        action: 'CREATE_TRANSACTION',
        data: {
          type: 'income',
          amount: parseFloat(amountMatch[1].replace(',', '.')),
          title: 'Receita',
          description: message,
          category: 'renda',
          subcategory: 'salarios',
          payment_method: 'account',
          status: 'received'
        },
        message: `✅ Receita de R$ ${parseFloat(amountMatch[1].replace(',', '.')).toFixed(2)} registrada!`,
        confidence: 0.95
      };
    }
  }
  
  return {
    action: 'ERROR',
    message: '🤖 Não consegui entender seu comando.\n\n📝 Comandos disponíveis:\n• "gastei 50 no supermercado"\n• "recebi 1200 de salário"\n• "criar caixinha viagem 5000"\n• "depositar 200 na caixinha viagem"\n• "saldo das caixinhas"',
    confidence: 0.0
  };
}

// Função para enviar mensagem de volta via Meta API
async function sendWhatsappMessage(to: string, message: string): Promise<boolean> {
  try {
    const metaApiToken = Deno.env.get('META_WHATSAPP_TOKEN');
    const fromPhoneNumberId = Deno.env.get('META_PHONE_NUMBER_ID');
    
    if (!metaApiToken || !fromPhoneNumberId) {
      console.error('Meta API credentials não configuradas');
      return false;
    }

    const metaApiUrl = `https://graph.facebook.com/v18.0/${fromPhoneNumberId}/messages`;

    const body = {
      messaging_product: "whatsapp",
      to: to,
      text: { body: message },
    };

    const response = await fetch(metaApiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${metaApiToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erro ao enviar mensagem WhatsApp:', errorText);
      return false;
    }

    console.log('Mensagem WhatsApp enviada com sucesso');
    return true;
  } catch (error) {
    console.error('Erro ao enviar mensagem WhatsApp:', error);
    return false;
  }
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verificação do webhook do WhatsApp (GET)
    if (req.method === 'GET') {
      console.log("🔍 Recebida requisição GET para verificação do webhook");
      
      const url = new URL(req.url);
      const mode = url.searchParams.get('hub.mode');
      const token = url.searchParams.get('hub.verify_token');
      const challenge = url.searchParams.get('hub.challenge');

      console.log(`📋 Parâmetros recebidos da Meta:`);
      console.log(`   - Modo: ${mode}`);
      console.log(`   - Token recebido: ${token}`);
      console.log(`   - Challenge: ${challenge}`);

      const expectedToken = Deno.env.get('META_VERIFY_TOKEN');
      console.log(`🔑 Token esperado (Supabase): ${expectedToken}`);

      if (mode === 'subscribe' && token === expectedToken) {
        console.log("✅ Validação do webhook bem-sucedida! Respondendo com challenge.");
        return new Response(challenge, { 
          status: 200,
          headers: corsHeaders
        });
      } else {
        console.error("❌ FALHA NA VALIDAÇÃO:");
        console.error(`   - Modo esperado: 'subscribe', recebido: '${mode}'`);
        console.error(`   - Token esperado: '${expectedToken}', recebido: '${token}'`);
        return new Response("Failed validation. Tokens do not match.", { 
          status: 403,
          headers: corsHeaders
        });
      }
    }

    // Processamento de mensagens (POST)
    if (req.method === 'POST') {
      console.log("📨 Recebida requisição POST - processando mensagem");
      
      const body = await req.json();
      console.log("📦 Payload completo recebido:", JSON.stringify(body, null, 2));

      // Verificar se é uma mensagem de texto válida
      if (body.object && body.entry?.[0]?.changes?.[0]?.value?.messages?.[0]) {
        const message = body.entry[0].changes[0].value.messages[0];
        const userPhoneNumber = message.from;
        const messageText = message.text?.body;

        console.log(`📱 Mensagem de ${userPhoneNumber}: "${messageText}"`);

        if (!messageText) {
          console.log("⚠️ Mensagem sem texto, ignorando");
          return new Response('OK', { status: 200, headers: corsHeaders });
        }

        // Buscar usuário pelo número do WhatsApp
        console.log(`🔍 Buscando usuário para o número: ${userPhoneNumber}`);
        
        const { data: whatsappUser, error: userError } = await supabase
          .from('whatsapp_users')
          .select('user_id')
          .eq('whatsapp_number', userPhoneNumber)
          .eq('is_verified', true)
          .single();

        if (userError || !whatsappUser) {
          console.log(`❌ Usuário não encontrado ou não verificado para: ${userPhoneNumber}`);
          
          // Enviar mensagem de erro
          await sendWhatsappMessage(
            userPhoneNumber, 
            "❌ Número não registrado ou não verificado.\n\n📱 Para usar este serviço:\n1. Acesse o Gestor Pro\n2. Vá em WhatsApp\n3. Conecte e verifique seu número\n\n🔗 Acesse: [seu-app-url]"
          );
          
          return new Response('User not found', { status: 200, headers: corsHeaders });
        }

        const userId = whatsappUser.user_id;
        console.log(`✅ Usuário encontrado: ${userId}`);

        // Processar mensagem com a Sofia
        console.log("🤖 Processando mensagem com Sofia...");
        const sofiaResponse = await processMessageWithSofia(messageText, userId);
        console.log("🎯 Resposta da Sofia:", JSON.stringify(sofiaResponse, null, 2));

        let responseMessage = sofiaResponse.message;
        let success = false;
        let actionTaken = sofiaResponse.action;

        // Registrar mensagem recebida
        const { data: messageRecord, error: messageError } = await supabase
          .from('whatsapp_messages')
          .insert({
            user_id: userId,
            whatsapp_number: userPhoneNumber,
            message_text: messageText,
            message_type: 'incoming',
            ai_response: responseMessage,
            action_taken: actionTaken
          })
          .select()
          .single();

        if (messageError) {
          console.error('Erro ao registrar mensagem:', messageError);
        }

        // Executar ação baseada na resposta da Sofia
        try {
          console.log(`⚡ Executando ação: ${sofiaResponse.action}`);
          
          switch (sofiaResponse.action) {
            case 'CREATE_TRANSACTION':
              console.log("💰 Criando transação...");
              
              const { error: transactionError } = await supabase
                .from('transactions')
                .insert({
                  user_id: userId,
                  title: sofiaResponse.data.title || sofiaResponse.data.description,
                  description: sofiaResponse.data.description,
                  user_description: messageText,
                  amount: sofiaResponse.data.amount,
                  type: sofiaResponse.data.type,
                  category: sofiaResponse.data.category || 'outros',
                  subcategory: sofiaResponse.data.subcategory,
                  payment_method: sofiaResponse.data.payment_method || 'cash',
                  status: sofiaResponse.data.status || (sofiaResponse.data.type === 'income' ? 'received' : 'paid'),
                  date: new Date().toISOString().split('T')[0],
                  whatsapp_message_id: messageRecord?.id
                });

              if (transactionError) {
                console.error('Erro ao criar transação:', transactionError);
                throw transactionError;
              }
              
              console.log("✅ Transação criada com sucesso");
              success = true;
              break;

            case 'CREATE_SAVINGS_BOX':
              console.log("🐷 Criando caixinha...");
              
              const { error: savingsError } = await supabase
                .from('savings_boxes')
                .insert({
                  user_id: userId,
                  name: sofiaResponse.data.name,
                  description: sofiaResponse.data.description,
                  target_amount: sofiaResponse.data.target_amount,
                  current_amount: 0,
                  monthly_contribution: 0,
                  bank_name: sofiaResponse.data.bank_name || 'Nubank',
                  cdi_percentage: sofiaResponse.data.cdi_percentage || 100,
                  risk_level: 'low',
                  auto_invest: false,
                  is_active: true
                });

              if (savingsError) {
                console.error('Erro ao criar caixinha:', savingsError);
                throw savingsError;
              }
              
              console.log("✅ Caixinha criada com sucesso");
              success = true;
              break;

            case 'DEPOSIT_SAVINGS':
              console.log("💵 Processando depósito em caixinha...");
              
              // Buscar caixinha pelo nome
              const { data: savingsBox, error: findError } = await supabase
                .from('savings_boxes')
                .select('*')
                .eq('user_id', userId)
                .eq('is_active', true)
                .ilike('name', `%${sofiaResponse.data.savings_box_name}%`)
                .single();

              if (findError || !savingsBox) {
                console.log(`❌ Caixinha '${sofiaResponse.data.savings_box_name}' não encontrada`);
                responseMessage = `❌ Caixinha '${sofiaResponse.data.savings_box_name}' não encontrada.\n\n💡 Crie primeiro com:\n"criar caixinha ${sofiaResponse.data.savings_box_name} [valor meta]"`;
                success = false;
                break;
              }

              // Atualizar saldo da caixinha
              const newAmount = savingsBox.current_amount + sofiaResponse.data.amount;
              const { error: updateError } = await supabase
                .from('savings_boxes')
                .update({ current_amount: newAmount })
                .eq('id', savingsBox.id);

              if (updateError) {
                console.error('Erro ao atualizar caixinha:', updateError);
                throw updateError;
              }

              // Registrar como transação
              const { error: depositTransactionError } = await supabase
                .from('transactions')
                .insert({
                  user_id: userId,
                  title: `Depósito - ${savingsBox.name}`,
                  description: sofiaResponse.data.description,
                  user_description: messageText,
                  amount: sofiaResponse.data.amount,
                  type: 'expense',
                  category: 'poupanca',
                  subcategory: 'reserva-longo-prazo',
                  payment_method: 'account',
                  status: 'paid',
                  date: new Date().toISOString().split('T')[0],
                  whatsapp_message_id: messageRecord?.id
                });

              if (depositTransactionError) {
                console.error('Erro ao registrar transação de depósito:', depositTransactionError);
                throw depositTransactionError;
              }

              const progress = ((newAmount / savingsBox.target_amount) * 100).toFixed(1);
              responseMessage = `✅ **Depósito realizado!**\n\n💰 R$ ${sofiaResponse.data.amount.toFixed(2)} → Caixinha ${savingsBox.name}\n📊 Saldo atual: R$ ${newAmount.toFixed(2)}\n🎯 Meta: R$ ${savingsBox.target_amount.toFixed(2)}\n📈 Progresso: ${progress}%`;
              
              console.log("✅ Depósito realizado com sucesso");
              success = true;
              break;

            case 'QUERY_SAVINGS':
              console.log("📊 Consultando saldo das caixinhas...");
              
              const { data: userSavingsBoxes, error: queryError } = await supabase
                .from('savings_boxes')
                .select('*')
                .eq('user_id', userId)
                .eq('is_active', true)
                .order('created_at', { ascending: false });

              if (queryError) {
                console.error('Erro ao consultar caixinhas:', queryError);
                throw queryError;
              }

              if (!userSavingsBoxes || userSavingsBoxes.length === 0) {
                responseMessage = '📦 **Nenhuma caixinha encontrada**\n\n💡 Crie sua primeira caixinha:\n"criar caixinha [nome] [valor meta]"\n\nExemplo:\n"criar caixinha viagem 5000"';
              } else {
                const totalSaved = userSavingsBoxes.reduce((sum, box) => sum + box.current_amount, 0);
                const totalTarget = userSavingsBoxes.reduce((sum, box) => sum + box.target_amount, 0);
                
                responseMessage = `💰 **SUAS CAIXINHAS**\n\n`;
                userSavingsBoxes.forEach(box => {
                  const progress = box.target_amount > 0 ? (box.current_amount / box.target_amount * 100).toFixed(1) : '0';
                  responseMessage += `🎯 **${box.name}**\n`;
                  responseMessage += `   💵 R$ ${box.current_amount.toFixed(2)} / R$ ${box.target_amount.toFixed(2)}\n`;
                  responseMessage += `   📊 ${progress}% concluído\n\n`;
                });
                
                responseMessage += `📈 **RESUMO GERAL**\n`;
                responseMessage += `💰 Total poupado: R$ ${totalSaved.toFixed(2)}\n`;
                responseMessage += `🎯 Total das metas: R$ ${totalTarget.toFixed(2)}\n`;
                if (totalTarget > 0) {
                  responseMessage += `📊 Progresso geral: ${((totalSaved / totalTarget) * 100).toFixed(1)}%`;
                }
              }
              
              console.log("✅ Consulta realizada com sucesso");
              success = true;
              break;

            case 'ERROR':
            default:
              console.log("⚠️ Comando não reconhecido ou erro");
              success = false;
              break;
          }
        } catch (actionError) {
          console.error('❌ Erro ao executar ação:', actionError);
          responseMessage = `❌ **Erro interno**\n\nNão foi possível processar sua solicitação. Tente novamente em alguns instantes.\n\n🔧 Código do erro: ${actionError.message}`;
          success = false;
        }

        // Atualizar registro da mensagem com resultado
        if (messageRecord) {
          await supabase
            .from('whatsapp_messages')
            .update({
              ai_response: responseMessage,
              success: success,
              error_message: success ? null : 'Erro ao processar ação'
            })
            .eq('id', messageRecord.id);
        }

        // Enviar resposta de volta via WhatsApp
        console.log("📤 Enviando resposta via WhatsApp...");
        const messageSent = await sendWhatsappMessage(userPhoneNumber, responseMessage);
        
        if (messageSent) {
          console.log("✅ Resposta enviada com sucesso");
        } else {
          console.log("⚠️ Falha ao enviar resposta (mas processamento foi concluído)");
        }

        return new Response(
          JSON.stringify({ 
            status: 'processed', 
            message: responseMessage,
            action: sofiaResponse.action,
            success: success,
            message_sent: messageSent
          }),
          { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200 
          }
        );
      }

      console.log("📝 Webhook recebido mas sem mensagem de texto válida");
      return new Response('EVENT_RECEIVED', { 
        status: 200, 
        headers: corsHeaders 
      });
    }

    return new Response('Method not allowed', { 
      status: 405, 
      headers: corsHeaders 
    });

  } catch (error) {
    console.error('💥 Erro crítico na função:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error.message 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});