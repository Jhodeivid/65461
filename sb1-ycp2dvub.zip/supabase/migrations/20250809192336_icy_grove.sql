/*
  # Create cdi_rates table

  1. New Tables
    - `cdi_rates`
      - `id` (uuid, primary key)
      - `date` (date, unique, required)
      - `rate` (numeric, required)
      - `source` (text, required)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `cdi_rates` table
    - Add policy for all authenticated users to read CDI rates
*/

CREATE TABLE IF NOT EXISTS public.cdi_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date UNIQUE NOT NULL,
  rate numeric NOT NULL,
  source text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

ALTER TABLE public.cdi_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all authenticated users"
  ON public.cdi_rates
  FOR SELECT
  TO authenticated
  USING (true);