/*
  # Create savings_boxes table

  1. New Tables
    - `savings_boxes`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text, required)
      - `description` (text, optional)
      - `target_amount` (numeric, required)
      - `current_amount` (numeric, default 0)
      - `monthly_contribution` (numeric, default 0)
      - `target_date` (date, optional)
      - `bank_name` (text, required)
      - `cdi_percentage` (numeric, default 100)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `is_active` (boolean, default true)
      - `auto_invest` (boolean, default false)
      - `risk_level` (text, default 'low')

  2. Security
    - Enable RLS on `savings_boxes` table
    - Add policies for authenticated users to manage their own savings boxes
*/

CREATE TABLE IF NOT EXISTS public.savings_boxes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  target_amount numeric NOT NULL,
  current_amount numeric DEFAULT 0 NOT NULL,
  monthly_contribution numeric DEFAULT 0 NOT NULL,
  target_date date,
  bank_name text NOT NULL,
  cdi_percentage numeric DEFAULT 100 NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  auto_invest boolean DEFAULT false NOT NULL,
  risk_level text DEFAULT 'low' NOT NULL,
  CONSTRAINT chk_risk_level CHECK (risk_level IN ('low', 'medium', 'high'))
);

ALTER TABLE public.savings_boxes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own savings boxes"
  ON public.savings_boxes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own savings boxes"
  ON public.savings_boxes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own savings boxes"
  ON public.savings_boxes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own savings boxes"
  ON public.savings_boxes
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.triggers
    WHERE trigger_name = 'update_savings_boxes_updated_at'
  ) THEN
    CREATE TRIGGER update_savings_boxes_updated_at
      BEFORE UPDATE ON public.savings_boxes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;