/*
  # Add INSERT policy for CDI rates table

  1. Security
    - Add policy to allow authenticated users to insert CDI rates
    - This enables the application to store new CDI rate data from external sources

  2. Changes
    - Add INSERT policy for authenticated users on cdi_rates table
*/

-- Add INSERT policy for CDI rates
CREATE POLICY "Enable insert access for authenticated users"
  ON cdi_rates
  FOR INSERT
  TO authenticated
  WITH CHECK (true);